close all;                          % close all figures
clear;                              % clear all variables
clc;                                % clear the command terminal

%% Import and plot sensor data
adrs='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\DataSim';
load([adrs, '/logfile_CAR_R01-2017_S4']);
RGB = imread('CAR.jpg');
start=1
finish=2
[Acc1,Gyr1,Mag1,AHR1,WIFI1,BLE1,Lgh1]= path_data_split2(start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh);
Acc=Acc1;Gyr=Gyr1;Mag=Mag1;AHR=AHR1;  % AHR(:,1)>> pitch    AHR(:,2)>> Roll   AHR(:,3)>> Yaw
WIFI=WIFI1;BLE=BLE1;Lgh=Lgh1;
%% Heading from Madgwick
%function [ heading_All, time]=Heading_Madgwick(Acc,Mag,Gyr)
num_acc_samples=size(Acc,1);                             % Acce samples
num_samples_mag=size(Mag,1);                             % Mag samples
tiempo_experimento=(Acc(end,4)-Acc(1,4));                % time of elapsed for measurement (m)
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
freq_Mag=ceil(num_samples_mag/tiempo_experimento);       % mag samples/s o Hz

%% initioal Heading from acc. and magn.
A= -309.8/1000;                  % X+ ==> East  micro tesla
B= 25657.3/1000;                 % Y+ ==> North micro tesla
D= -36694.9/1000;                % Z+ ==> Down micro tesla
% initialize Roll, Pitch, Yaw
ax=Acc(1,1);ay=Acc(1,2);az=Acc(1,3);
mx=Mag(ceil(freq_Mag/freq_Acc),1);
my=Mag(ceil(freq_Mag/freq_Acc),2);
mz=Mag(ceil(freq_Mag/freq_Acc),3);
Rol=atan2(-ax , az);                   % rad
pitch=atan2(ay , sqrt(ax^2 + az^2) );  % rad
r_deg=rad2deg(Rol);                    % deg
p_deg=rad2deg(pitch);                  % deg
F=mx*cos(Rol)+mz*sin(Rol);
G=mx*sin(Rol)*sin(pitch) - mz*sin(pitch)*cos(Rol) + my*cos(pitch);
Yaw_rad=atan2( B*F-A*G , A*F+B*G );
Yaw_deg1=rad2deg(Yaw_rad);
Yaw_deg2=mod(Yaw_deg1+360 , 360 );
yaw_r=deg2rad(Yaw_deg2);
Yaw_ini=yaw_r;
if Yaw_deg1<=0
    bearing=-1*Yaw_deg1;
else
    bearing=360-Yaw_deg1;
end
Rot_z=[cos(Yaw_ini)  sin(Yaw_ini) 0; -sin(Yaw_ini) cos(Yaw_ini) 0; 0 0 1];        % from n-frame to b-frame
Rot_y=[cos(Rol) 0 -sin(Rol); 0 1 0;  sin(Rol)   0 cos(Rol)];                      % from n-frame to b-frame
Rot_x=[1 0 0; 0 cos(pitch)  sin(pitch); 0 -sin(pitch) cos(pitch)];                % from n-frame to b-frame
Rot_nb=Rot_y(:,:)*Rot_x(:,:)*Rot_z(:,:);                                          % from n-frame to b-frame
%% Current filter state.
q_nb=DCM2Quaternion(Rot_nb); % Unit quaternion
%% **********************************************************************************
%% Process sensor data through algorithm
SamplePeriod=1/137;
Beta=.1;
gyroMeasError=3.14159265358979 * (5 / 180)
Beta=sqrt(3 / 4) * gyroMeasError
quaternion = zeros(length(Gyr), 4);
Quaternion = q_nb';     % output quaternion describing the Earth relative to the sensor
n=0;
for t = 1:length(Gyr)
    n=n+1;
    Qnb=Quaternion;
    
    tim(t)=Gyr(t,4);
    [~,s(n,1)]=min(abs(bsxfun(@minus,Gyr(:,4), repmat(tim(t),[size(Gyr,1),1]))));
    [~,s(n,2)]=min(abs(bsxfun(@minus,Acc(:,4), repmat(tim(t),[size(Acc,1),1]))));
    [~,s(n,3)]=min(abs(bsxfun(@minus,Mag(:,4), repmat(tim(t),[size(Mag,1),1]))));
    
    GYR = Gyr(s(n,1),1:3);    % Gyroscope
    ACC = Acc(s(n,2),1:3);    % Acc
    MAG = Mag(s(n,3),1:3);    % Mag
    
    if(norm(ACC) == 0), return; end	% handle NaN
    ACCe= ACC / norm(ACC);                   	% normalise magnitude
    if(norm(MAG) == 0), return; end	% handle NaN
    Magn = MAG / norm(MAG);	                % normalise magnitude
    % Reference direction of Earth's magnetic feild
    
    mag_qb=[0 Magn];
    conj_q=[Qnb(:,1) -Qnb(:,2) -Qnb(:,3) -Qnb(:,4)]; % b2n
    a=mag_qb;
    b=conj_q;  % mag.q*
    ab(:,1) = a(:,1).*b(:,1)-a(:,2).*b(:,2)-a(:,3).*b(:,3)-a(:,4).*b(:,4);
    ab(:,2) = a(:,1).*b(:,2)+a(:,2).*b(:,1)+a(:,3).*b(:,4)-a(:,4).*b(:,3);
    ab(:,3) = a(:,1).*b(:,3)-a(:,2).*b(:,4)+a(:,3).*b(:,1)+a(:,4).*b(:,2);
    ab(:,4) = a(:,1).*b(:,4)+a(:,2).*b(:,3)-a(:,3).*b(:,2)+a(:,4).*b(:,1);
    aa=Qnb;
    bb=ab;      % q.mag.q*
    h(:,1) = aa(:,1).*bb(:,1)-aa(:,2).*bb(:,2)-aa(:,3).*bb(:,3)-aa(:,4).*bb(:,4);
    h(:,2) = aa(:,1).*bb(:,2)+aa(:,2).*bb(:,1)+aa(:,3).*bb(:,4)-aa(:,4).*bb(:,3);
    h(:,3) = aa(:,1).*bb(:,3)-aa(:,2).*bb(:,4)+aa(:,3).*bb(:,1)+aa(:,4).*bb(:,2);
    h(:,4) = aa(:,1).*bb(:,4)+aa(:,2).*bb(:,3)-aa(:,3).*bb(:,2)+aa(:,4).*bb(:,1);
    M01(n,1:4) = [0 h(2) h(3) h(4)];
    M0 =M01 /norm(M01 );
    M0=[0 A B D]/norm([0 A B D]);
    
    %%% Gradient decent algorithm corrective step
    
    F=[2*(Qnb(2)*Qnb(4) - Qnb(1)*Qnb(3)) - ACCe(1)
        2*(Qnb(1)*Qnb(2) + Qnb(3)*Qnb(4)) - ACCe(2)
        2*(-0.5 + Qnb(1)^2 + Qnb(4)^2) - ACCe(3)
        2*M0(2)*(-0.5+Qnb(1)^2+Qnb(2)^2)+2*M0(3)*(Qnb(2)*Qnb(3)+Qnb(1)*Qnb(4))+2*M0(4)*(Qnb(2)*Qnb(4)-Qnb(1)*Qnb(3))-Magn(1)
        2*M0(2)*(Qnb(2)*Qnb(3)-Qnb(1)*Qnb(4))+2*M0(3)*(-0.5+Qnb(1)^2+Qnb(3)^2)+2*M0(4)*(Qnb(3)*Qnb(4)+Qnb(1)*Qnb(2))-Magn(2)
        2*M0(2)*(Qnb(2)*Qnb(4)+Qnb(1)*Qnb(3))+2*M0(3)*(Qnb(3)*Qnb(4)-Qnb(1)*Qnb(2))+2*M0(4)*(-0.5+Qnb(1)^2+Qnb(4)^2)-Magn(3)];
    
    J = [-2*Qnb(3),                 	2*Qnb(4),                    -2*Qnb(1),                         2*Qnb(2)
        2*Qnb(2),                 	2*Qnb(1),                    	2*Qnb(4),                         2*Qnb(3)
        0,                         -4*Qnb(2),                    -4*Qnb(3),                         0
        4*M0(2)*Qnb(1)+2*M0(3)*Qnb(4)-2*M0(4)*Qnb(3),4*M0(2)*Qnb(2)+2*M0(3)*Qnb(3)+2*M0(4)*Qnb(4), 2*M0(2)*Qnb(2)-2*M0(4)*Qnb(1), 2*M0(3)*Qnb(1)+2*M0(4)*Qnb(2)
        -2*M0(2)*Qnb(4)+4*M0(3)*Qnb(1)+2*M0(4)*Qnb(2),2*M0(2)*Qnb(3)+2*M0(4)*Qnb(1), 2*M0(2)*Qnb(2)+4*M0(3)*Qnb(3)+2*M0(4)*Qnb(4),-2*M0(2)*Qnb(1)+2*M0(4)*Qnb(3)
        2*M0(2)*Qnb(3)-2*M0(3)*Qnb(2)+4*M0(4)*Qnb(1),  2*M0(2)*Qnb(4)-2*M0(3)*Qnb(1), 2*M0(2)*Qnb(1)+2*M0(3)*Qnb(4), 2*M0(2)*Qnb(2)+2*M0(3)*Qnb(3)+4*M0(4)*Qnb(4)];
    
    Gradient = (J'*F);
    Gradient = Gradient / norm(Gradient);	% normalise step magnitude
%       
%     a1=Qnb;
%     b1=Gradient';
%     err_Prod(:,1) = a1(:,1).*b1(:,1)-a1(:,2).*b1(:,2)-a1(:,3).*b1(:,3)-a1(:,4).*b1(:,4);
%     err_Prod(:,2) = a1(:,1).*b1(:,2)+a1(:,2).*b1(:,1)+a1(:,3).*b1(:,4)-a1(:,4).*b1(:,3);
%     err_Prod(:,3) = a1(:,1).*b1(:,3)-a1(:,2).*b1(:,4)+a1(:,3).*b1(:,1)+a1(:,4).*b1(:,2);
%     err_Prod(:,4) = a1(:,1).*b1(:,4)+a1(:,2).*b1(:,3)-a1(:,3).*b1(:,2)+a1(:,4).*b1(:,1);
%     err_Prod=2.*err_Prod;
%     zeta=0.0031;
%     wb=err_Prod* SamplePeriod*zeta;
%     GYR=GYR-wb(1,2:end);
% %     
    
    a=Qnb;
    Gr_b=[0 GYR];
    gq_Prod(:,1) = a(:,1).*Gr_b(:,1)-a(:,2).*Gr_b(:,2)-a(:,3).*Gr_b(:,3)-a(:,4).*Gr_b(:,4);
    gq_Prod(:,2) = a(:,1).*Gr_b(:,2)+a(:,2).*Gr_b(:,1)+a(:,3).*Gr_b(:,4)-a(:,4).*Gr_b(:,3);
    gq_Prod(:,3) = a(:,1).*Gr_b(:,3)-a(:,2).*Gr_b(:,4)+a(:,3).*Gr_b(:,1)+a(:,4).*Gr_b(:,2);
    gq_Prod(:,4) = a(:,1).*Gr_b(:,4)+a(:,2).*Gr_b(:,3)-a(:,3).*Gr_b(:,2)+a(:,4).*Gr_b(:,1);
    
    qDot=0.5*gq_Prod - Beta * Gradient';
    
    % Integrate to yield quaternion
    Qnb = Qnb + qDot * SamplePeriod;
    Quaternion = Qnb / norm(Qnb); % normalise quaternion
    %Quaternion=Quaternion.*sign(Quaternion(1));
    quaternion(t, :) = Quaternion;
    %%%%%%%%%%%  Save estimates
    x=Quaternion;
    c_nb_12=2*x(2)*x(3) + 2*x(1)*x(4);% roll=-tana2(c_bn_31, c_bn_33)
    c_nb_22=2*x(1)^2-1+2*x(3)^2;
    YAW_Rad=atan2(c_nb_12, c_nb_22); %YAW_Rad=atan2(-c_nb_12, c_nb_22);
    YAW_Deg1(n)=rad2deg(YAW_Rad);
    yy=mod(rad2deg(YAW_Rad)+360 , 360 );
    if yy<=0
        bearing(n)=-1*yy;
    else
        bearing(n)=360-yy;
    end
end

plot(tim,bearing)
legend('Madgwick Filter')