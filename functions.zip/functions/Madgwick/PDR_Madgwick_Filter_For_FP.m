clc;
clear all;
close all;

% start =25;     % 1  12    16  20  20  65  41  41  50  60
% finish=26;     % 8  23    26  30  40  75  46  52  61  71
adrs='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\DataSim';
load([adrs, '/logfile_CAR_R01-2017_S4']);
adr2='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\Code_Sim\CAR\Validation\Madgwick_Comp'
addpath([adr2,'/common_func/']);
load([adrs,'/net'])
% addpath(genpath('common_func'))
pa_num=size(Posi,1)-1;
RGB = imread('CAR.jpg');
K=0.345;
I = rgb2gray(RGB);scale=0.05207600;
lonX= -3.48367648;latY= 40.31320308;angle=-8.77680000;
[P0x P0y]=ll2utm([40.31320308 -3.48367648]);
% lat lon to m
LAT=Posi(:,3);
LON=Posi(:,4);
[refX,refY]=ll2utm(LAT,LON);
 
 % path=path+1
for path=1:pa_num  % for each path
    
    start=path;
    p_num=path
    finish=path+1;
    [Acc1,Gyr1,Mag1,AHR1,WIFI1,BLE1,Lgh1,s_e_point,stim,ftim]= path_data_split2(start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh);
    Acc{path}=Acc1;
    Gyr{path}=Gyr1;
    Mag{path}=Mag1;
    AHR{path}=AHR1;  % AHR(:,1)>> pitch    AHR(:,2)>> Roll   AHR(:,3)>> Yaw
    WIFI{path}=WIFI1;       % db
    BLE{path}=BLE1;        % db
    Lgh{path}=Lgh1;
    
    %% step detection in each path
    [StanceBegins_idx,time_step,Num_steps] = Step_Detection(Acc{path});
    Step_events=StanceBegins_idx;
    Timestep{path}=time_step;
    Step_event{path}=Step_events;                          % number of samples that step is evented
    Number_steps(path)=length(Step_event{1,path});              % number  of all steps
    %% StepLenght estimation
    num_samples_Acc=size(Acc{path},1);
    % 1) ACCe Magnitude
    M_Acc=sqrt(Acc{path}(:,1).^2+Acc{path}(:,2).^2+Acc{path}(:,3).^2);
    % 2) Filter
    tiempo_experimento=(Acc{path}(end,4)-Acc{path}(1,4));
    num_acc_samples=size(Acc{path},1);                             % Acce samples
    freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
    [b,a] = butter(4,3/freq_Acc,'low');
    M_Acc=filtfilt(b,a,M_Acc);
    % 3) Formula Analog Devices (Weiberg paper)  SL Estimation
    sample_ini=1;
    num_Step_events=length(Step_event{path});
    for i=1:num_Step_events                    % for each of the steps detected
        sample_Step_event=Step_event{path}(i);
        Acc_max(i)=max(M_Acc(sample_ini:sample_Step_event));
        Acc_min(i)=min(M_Acc(sample_ini:sample_Step_event));
        Bounce(i)=(Acc_max(i)-Acc_min(i))^(1/4);
        StrideLengths{path}(i)=Bounce(i)*K*2;
        sample_ini= sample_Step_event;
    end
    
    %% heading for ALL  samples from EKF
beta=.35;zeta=0.016;
gyroMeasError=pi * (50 / 180)
%beta=sqrt(3 / 4) * gyroMeasError
[ Heading_Madg, tim, phone_state]=Heading_Madgwick(Acc{path},Mag{path},Gyr{path},beta,zeta);
%     [bearALL ,Time_sampling]=Heading_EKF_1(Acc{path},Mag{path},Gyr{path});
    BearingALLQ_Madg{path}=Heading_Madg(1,:);
    ttime{path}=tim;
    
    %% heading in each step
    
    for sn=1:size(Timestep{path},1)
        [~,dd]=min(abs(bsxfun(@minus, ttime{path}(1,:),...
            repmat( Timestep{path}(sn),[1, size(ttime{path},2)] ))));
        hse(sn)=dd;  % heading_sam_ekf
        
    end
    %% Destination from madg Heading
    p=Posi(:,3:4);                     % Posi ; 3 lat>0,  4 lon <0
    R = 6371; % km
    phi1_ekf=deg2rad(p(start,1));       % lat 1 radian
    lambda1_ekf= deg2rad(p(start,2));   % lon 1
    ltLon_ekf(1,1)=p(start,1);
    ltLon_ekf(1,2)=p(start,2);
    latLon_g(1,1)=p(start,1);
    latLon_g(1,2)=p(start,2);
     gg=size(StrideLengths{path},2); % [1* ...]
    for jj=1:gg
        dis=StrideLengths{path}(1,jj);
        Bear_ekf=BearingALLQ_Madg{path}(1,hse(1,jj));
        c=dis/(R*1000);    % dis/R(in meter)
        phi_ekf = asin( sin(phi1_ekf)*cos(c) + sin(c)*cos(deg2rad(Bear_ekf))*cos(phi1_ekf));    % lat
        lambda_ekf = lambda1_ekf +  atan2( sin(deg2rad(Bear_ekf))* sin(c)* cos(phi1_ekf), cos(c)- sin(phi1_ekf)* sin(phi_ekf));  % lon
        ltLon_ekf(jj+1,1)=rad2deg(phi_ekf);
        ltLon_ekf(jj+1,2)=rad2deg(lambda_ekf);
        phi1_ekf=phi_ekf;
        lambda1_ekf=lambda_ekf;
    end
    latLon_madg{path}= ltLon_ekf;
    clear ltLon_ekf
    %% PDR_OLd
    [X_pdr,Y_pdr]=ll2utm(latLon_madg{path}(:,1),latLon_madg{path}(:,2)); % latlon to utm (meter)[Px0,Py0]=ll2utm(latY,lonX)
    n=size(StrideLengths{path},2);
    step_tim(1,1)=stim;
    step_tim(2:n+1,1)=time_step;
    Pdr_old{path}(1:3,1:n+1)=[X_pdr';Y_pdr';step_tim'];
    %% End Old
    %% -------------------- New PDR ---------------------------------------
    P_new{path}(1:3,1)=Pdr_old{path}(1:3,1);
    P_new{path}(1:3,n+1)=[refX(finish),refY(finish),Pdr_old{path}(3,end)];
    dt=Pdr_old{path}(3,end)-Pdr_old{path}(3,2);
    i=n
    t1=Pdr_old{path}(3,2);
    ex=refX(finish)-Pdr_old{path}(1,n+1)
    ey=refY(finish)-Pdr_old{path}(2,n+1)
    vvX=Pdr_old{path}(1,n+1)+ex
    vvY=Pdr_old{path}(2,n+1)+ey
    for j=1:n-1 % j=j+1
        t_cur=Pdr_old{path}(3,i);
        t_endstp=Pdr_old{path}(3,end);
        %     % (1) yes
        er_x=ex*((n-j)/n);
        er_y=ey*((n-j)/n);
        % (2) no
        %     er_x=ex*(Pdr_old(3,i)/dt);
        %     er_y=ey*(Pdr_old(3,i)/dt);
        % (3)
        %     er_x=ex*((Pdr_old(3,i)-t1)/dt);
        %     er_y=ey*((Pdr_old(3,i)-t1)/dt);
        % (4) perfect :D !!!!
        %     er_x=ex*((Pdr_old(3,i)-t1)/dt)*((n-j)/n);
        %     er_y=ey*((Pdr_old(3,i)-t1)/dt)*((n-j)/n);
        % (5) no
        %     er_x=ex*((t_cur*(n-j))-(t1))/(dt*((n*t_endstp)-(t_cur*(n-j))));
        %     er_y=ey*((t_cur*(n-j))-(t1))/(dt*((n*t_endstp)-(t_cur*(n-j))));
        % (6) no
        %     st=(Pdr_old(3,i)-t1)/(dt*(Pdr_old(3,end)-Pdr_old(3,i)));
        %     er_x=ex*st
        %     er_y=ey*st
        xj=Pdr_old{path}(1,i)+er_x;
        yj=Pdr_old{path}(2,i)+er_y;
        P_new{path}(1:3,i)=[xj,yj,Pdr_old{path}(3,i)];
        %
        %
        i=i-1
    end
clear step_tim
clear X_pdr
clear Y_pdr
%% END new PDR  
%     scale=0.05207600;                     % meter/pixel
%     lonX= -3.48367648;     % lon degree
%     latY= 40.31320308;     % lat
%     angle=-8.77680000;
%     [p_x p_y]=latlon2pixel(latLon_EKF{path},RGB,angle,scale,lonX,latY);
%     PiXel_EKF{path}=[p_x;p_y]; 
end
[refX_pxc refY_pxc]=Meter2pixel([refX(1:end),refY(1:end)],RGB,angle,scale,P0x,P0y);
imshow(I);
hold on
plot(refX_pxc,refY_pxc,'*:')
axis auto
for path=1:pa_num
    hold on
    [Xnew_pxc Ynew_pxc]=Meter2pixel([P_new{path}(1,:)',P_new{path}(2,:)'],RGB,angle,scale,P0x,P0y);
    hold on
    plot(Xnew_pxc ,Ynew_pxc,'r.');
end
legend('ref','corrected trajectory')
hold off
figure(2)
imshow(I);
hold on
plot(refX_pxc,refY_pxc,'--go',...
    'LineWidth',2,...
    'MarkerSize',8,...
    'MarkerEdgeColor','b',...
    'MarkerFaceColor','b')
for i=1:size(refX_pxc,1)
  text(refX_pxc(i,1),refY_pxc(i,1),num2str(i),'FontSize',8,'Color','k'); 
end
axis auto
for path=1:pa_num
    hold on
    [X_pdr_pxc Y_pdr_pxc]=Meter2pixel([Pdr_old{path}(1,:)',Pdr_old{path}(2,:)'],RGB,angle,scale,P0x,P0y);
    plot(X_pdr_pxc,Y_pdr_pxc,'b.')
end
legend('ref','raw trajectory')




% [px py]=latlon2pixel(Posi(:,3:4),RGB,angle,scale,lonX,latY);
% %% Plot
% I = rgb2gray(RGB);
% imshow(I)
% hold on
% plot(px,py,'o:')           % ref point
% for i=1:size(px,2)
%   text(px(1,i),py(1,i),num2str(i)); 
% end
% hold on
% for fig=1:pa_num 
%     plot(PiXel_EKF{fig}(1,:),PiXel_EKF{fig}(2,:),'b.-','Linewidth',1)
%     hold on
% end
% 
% axis auto
% legend('Ref. point','EKF')
