function [ heading_All, time,phone_pose]=Heading_Madgwick(Aceb,Magb,Gyrb,beta1,zeta1)

% Aceb=Acc;Magb=Mag;Gyrb=Gyr;
num_samples_g=size(Gyrb,1);
num_acc_samples=size(Aceb,1);                             % Acce samples
num_samples_mag=size(Magb,1);                             % Mag samples
tiempo_experimento=(Aceb(end,4)-Aceb(1,4));                % time of elapsed for measurement (m)
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
freq_Mag=ceil(num_samples_mag/tiempo_experimento);       % mag samples/s o Hz
freq_gyro=ceil(num_samples_g/tiempo_experimento);
%% initioal Heading from acc. and magn.
Mx_n= -309.8/1000;                  % X+ ==> East  micro tesla
My_n= 25657.3/1000;                 % Y+ ==> North micro tesla
Mz_n= -36694.9/1000;                % Z+ ==> Down micro tesla
% initialize Roll, Pitch, Yaw
ax_b=Aceb(1,1);ay_b=Aceb(1,2);az_b=Aceb(1,3);
mx_b=Magb(ceil(freq_Mag/freq_Acc),1);
my_b=Magb(ceil(freq_Mag/freq_Acc),2);
mz_b=Magb(ceil(freq_Mag/freq_Acc),3);
Rol=atan2(-ax_b , az_b);                   % rad n2b
pit=atan2(ay_b , sqrt(ax_b^2 + az_b^2) );    % rad
r_deg=rad2deg(Rol);                    % deg
p_deg=rad2deg(pit);                    % deg
F=mx_b*cos(Rol)+mz_b*sin(Rol);
G=mx_b*sin(Rol)*sin(pit) - mz_b*sin(pit)*cos(Rol) + my_b*cos(pit);
Yaw_rad=atan2( My_n*F-Mx_n*G , Mx_n*F+My_n*G );
Yaw_deg1=rad2deg(Yaw_rad);
Yaw_deg2=mod(Yaw_deg1+360 , 360 );
yaw_r=deg2rad(Yaw_deg2);
Yaw_ini=yaw_r;
if Yaw_deg1<=0
    bearing_mg=-1*Yaw_deg1;
else
    bearing_mg=360-Yaw_deg1;
end
Rot_z=[cos(Yaw_ini)  sin(Yaw_ini) 0; -sin(Yaw_ini) cos(Yaw_ini) 0; 0 0 1];        % from n-frame to b-frame
Rot_y=[cos(Rol) 0 -sin(Rol); 0 1 0;  sin(Rol)   0 cos(Rol)];                      % from n-frame to b-frame
Rot_x=[1 0 0; 0 cos(pit)  sin(pit); 0 -sin(pit) cos(pit)];                % from n-frame to b-frame
Rot_bn=Rot_y(:,:)*Rot_x(:,:)*Rot_z(:,:);                                          % from n-frame to b-frame
%% Current filter state.
q_bn=DCM2Quaternion(Rot_bn); % Unit quaternion
% q_bn=DCM2Quaternion(Rot_nb)
%% Process sensor data through algorithm
SamplePeriod=1/freq_gyro
quaternion = zeros(length(Gyrb), 4);
Quaternion_nb  = q_bn';     % output quaternion describing the Earth relative to the sensor
n=0;
%% ^^^^^^^^^^^^^^^^^^^^^^^^^^^^     Filter Loop     ^^^^^^^^^^^^^^^^^^^^^^^
for t = 1:length(Gyrb)
    n=n+1;
    Qnb=Quaternion_nb;
    
    tim(t)=Gyrb(t,4);
    % find co time samples of Acc and Magn with current Gyro
    [~,s(n,1)]=min(abs(bsxfun(@minus,Gyrb(:,4), repmat(tim(t),[size(Gyrb,1),1]))));
    [~,s(n,2)]=min(abs(bsxfun(@minus,Aceb(:,4), repmat(tim(t),[size(Aceb,1),1]))));
    [~,s(n,3)]=min(abs(bsxfun(@minus,Magb(:,4), repmat(tim(t),[size(Magb,1),1]))));
    
    GYR = Gyrb(s(n,1),1:3);    % Gyroscope
    ACC = Aceb(s(n,2),1:3);    % Acc
    MAG = Magb(s(n,3),1:3);    % Mag
    
    if(norm(ACC) == 0), return; end	% handle NaN
    ACC_nrm= ACC / norm(ACC);                   	% normalise magnitude
    if(norm(MAG) == 0), return; end	% handle NaN
    Mag_nrm = MAG / norm(MAG);	                % normalise magnitude
    % Reference direction of Earth's magnetic feild
    mag_qb=[0 Mag_nrm];
    
    conj_q=[Qnb(:,1) -Qnb(:,2) -Qnb(:,3) -Qnb(:,4)]; % q_bn
    a=mag_qb;
    b=conj_q;  
    % vvvvv  mag . q_bn vvvvvvvvv
    ab(:,1) = a(:,1).*b(:,1)-a(:,2).*b(:,2)-a(:,3).*b(:,3)-a(:,4).*b(:,4);
    ab(:,2) = a(:,1).*b(:,2)+a(:,2).*b(:,1)+a(:,3).*b(:,4)-a(:,4).*b(:,3);
    ab(:,3) = a(:,1).*b(:,3)-a(:,2).*b(:,4)+a(:,3).*b(:,1)+a(:,4).*b(:,2);
    ab(:,4) = a(:,1).*b(:,4)+a(:,2).*b(:,3)-a(:,3).*b(:,2)+a(:,4).*b(:,1);
    clear a b
    a=Qnb;
    bb=ab;      
    % vvvv  q_nb.mag.q_bn  vvvvvv
    h(:,1) = a(:,1).*bb(:,1)-a(:,2).*bb(:,2)-a(:,3).*bb(:,3)-a(:,4).*bb(:,4);
    h(:,2) = a(:,1).*bb(:,2)+a(:,2).*bb(:,1)+a(:,3).*bb(:,4)-a(:,4).*bb(:,3);
    h(:,3) = a(:,1).*bb(:,3)-a(:,2).*bb(:,4)+a(:,3).*bb(:,1)+a(:,4).*bb(:,2);
    h(:,4) = a(:,1).*bb(:,4)+a(:,2).*bb(:,3)-a(:,3).*bb(:,2)+a(:,4).*bb(:,1);
    %M0 = [0 h(2) h(3) h(4)]/norm([0 h(2) h(3) h(4)]);
    M0_n=[0 Mx_n My_n Mz_n]/norm([0 Mx_n My_n Mz_n]);
    %M0 = [0 norm([h(2) h(3)]) 0 h(4)];
    %%% Gradient decent algorithm corrective step
    
    F= [2*(Qnb(2)*Qnb(4) - Qnb(1)*Qnb(3)) - ACC_nrm(1)
        2*(Qnb(1)*Qnb(2) + Qnb(3)*Qnb(4)) - ACC_nrm(2)
        2*(-0.5 + Qnb(1)^2 + Qnb(4)^2) - ACC_nrm(3)
        2*M0_n(2)*(-0.5+Qnb(1)^2+Qnb(2)^2)+2*M0_n(3)*(Qnb(2)*Qnb(3)+Qnb(1)*Qnb(4))+2*M0_n(4)*(Qnb(2)*Qnb(4)-Qnb(1)*Qnb(3))-Mag_nrm(1)
        2*M0_n(2)*(Qnb(2)*Qnb(3)-Qnb(1)*Qnb(4))+2*M0_n(3)*(-0.5+Qnb(1)^2+Qnb(3)^2)+2*M0_n(4)*(Qnb(3)*Qnb(4)+Qnb(1)*Qnb(2))-Mag_nrm(2)
        2*M0_n(2)*(Qnb(2)*Qnb(4)+Qnb(1)*Qnb(3))+2*M0_n(3)*(Qnb(3)*Qnb(4)-Qnb(1)*Qnb(2))+2*M0_n(4)*(-0.5+Qnb(1)^2+Qnb(4)^2)-Mag_nrm(3)];
    
    J = [-2*Qnb(3),                 	2*Qnb(4),                    -2*Qnb(1),                         2*Qnb(2)
        2*Qnb(2),                 	2*Qnb(1),                    	2*Qnb(4),                         2*Qnb(3)
        0,                         -4*Qnb(2),                    -4*Qnb(3),                         0
        4*M0_n(2)*Qnb(1)+2*M0_n(3)*Qnb(4)-2*M0_n(4)*Qnb(3),4*M0_n(2)*Qnb(2)+2*M0_n(3)*Qnb(3)+2*M0_n(4)*Qnb(4), 2*M0_n(2)*Qnb(2)-2*M0_n(4)*Qnb(1), 2*M0_n(3)*Qnb(1)+2*M0_n(4)*Qnb(2)
        -2*M0_n(2)*Qnb(4)+4*M0_n(3)*Qnb(1)+2*M0_n(4)*Qnb(2),2*M0_n(2)*Qnb(3)+2*M0_n(4)*Qnb(1), 2*M0_n(2)*Qnb(2)+4*M0_n(3)*Qnb(3)+2*M0_n(4)*Qnb(4),-2*M0_n(2)*Qnb(1)+2*M0_n(4)*Qnb(3)
        2*M0_n(2)*Qnb(3)-2*M0_n(3)*Qnb(2)+4*M0_n(4)*Qnb(1),  2*M0_n(2)*Qnb(4)-2*M0_n(3)*Qnb(1), 2*M0_n(2)*Qnb(1)+2*M0_n(3)*Qnb(4), 2*M0_n(2)*Qnb(2)+2*M0_n(3)*Qnb(3)+4*M0_n(4)*Qnb(4)];
    
    Gradient = (J'*F);
    Gradient = Gradient / norm(Gradient);	% normalise step magnitude
    
    
        a1=Qnb;
        b1=Gradient';
        err_Prod(:,1) = a1(:,1).*b1(:,1)-a1(:,2).*b1(:,2)-a1(:,3).*b1(:,3)-a1(:,4).*b1(:,4);
        err_Prod(:,2) = a1(:,1).*b1(:,2)+a1(:,2).*b1(:,1)+a1(:,3).*b1(:,4)-a1(:,4).*b1(:,3);
        err_Prod(:,3) = a1(:,1).*b1(:,3)-a1(:,2).*b1(:,4)+a1(:,3).*b1(:,1)+a1(:,4).*b1(:,2);
        err_Prod(:,4) = a1(:,1).*b1(:,4)+a1(:,2).*b1(:,3)-a1(:,3).*b1(:,2)+a1(:,4).*b1(:,1);
        err_Prod=2.*err_Prod;
%         zeta1=0.016;
        wb=err_Prod* SamplePeriod*zeta1;
        GYR=GYR-wb(1,2:end);
    
    a=Qnb;
    Gr_b=[0 GYR];
    gq_Prod(:,1) = a(:,1).*Gr_b(:,1)-a(:,2).*Gr_b(:,2)-a(:,3).*Gr_b(:,3)-a(:,4).*Gr_b(:,4);
    gq_Prod(:,2) = a(:,1).*Gr_b(:,2)+a(:,2).*Gr_b(:,1)+a(:,3).*Gr_b(:,4)-a(:,4).*Gr_b(:,3);
    gq_Prod(:,3) = a(:,1).*Gr_b(:,3)-a(:,2).*Gr_b(:,4)+a(:,3).*Gr_b(:,1)+a(:,4).*Gr_b(:,2);
    gq_Prod(:,4) = a(:,1).*Gr_b(:,4)+a(:,2).*Gr_b(:,3)-a(:,3).*Gr_b(:,2)+a(:,4).*Gr_b(:,1);
    % beta1 = beta
    qDot=0.5*gq_Prod - beta1
    qDot=0.5*gq_Prod - beta1 * Gradient';
    
    % Integrate to yield quaternion
    Qnb = Qnb + qDot * SamplePeriod;
    Quaternion_nb = Qnb / norm(Qnb); % normalise quaternion
    Quaternion_nb=Quaternion_nb.*sign(Quaternion_nb(1));
    quaternion(t, :) = Quaternion_nb;
    %%%%%%%%%%%  Save estimates
    x_b=Quaternion_nb;
    c_bn_12=2*x_b(2)*x_b(3) + 2*x_b(1)*x_b(4);
    c_bn_22=2*x_b(1)^2-1+2*x_b(3)^2;
    c_bn_31=2*x_b(2)*x_b(4) - 2*x_b(1)*x_b(3);
    c_bn_33=2*x_b(1)^2-1+2*x_b(4)^2;
    c_bn_32=2*x_b(3)*x_b(4) - 2*x_b(1)*x_b(2);

    YAW_Rad=-atan2(c_bn_12, c_bn_22); % yaw is  n 2 b == bearing == - b2n
    Yaw_deg(n)=rad2deg(YAW_Rad);
    r_deg(n)=rad2deg(-atan2(c_bn_31, c_bn_33));
    p_deg(n)=rad2deg(atan2(c_bn_32,sqrt((c_bn_12)^2 + (c_bn_22)^2)));
   % yy(n)=mod(rad2deg(YAW_Rad)+360 , 360 );
    
    if (r_deg(n)<=-74 )&& (r_deg(n)>=-100) &&(p_deg(n)<=0)&&(p_deg(n)>=-50) && (Yaw_deg(n)<= 56)&&(Yaw_deg(n)>=30)
        yy(n)=mod(r_deg(n)+360 , 360) -90;
    else
        yy(n)=mod(Yaw_deg(n)+360 , 360);
    end
    %     if yy(n)<=0
    %         bearing(n)=-1*yy(n);% %
    %     else
    %         bearing(n)=360-yy(n);
    %     end
    bearing(n)=yy(n);
end
heading_All=bearing;
phone_pose.roll=r_deg;
phone_pose.Pitch=p_deg ;
phone_pose.yaw=Yaw_deg;
time=tim;
Sam_num=s;
end
% plot(Yaw_deg); hold on