close all;                          % close all figures
clear;                              % clear all variables
clc;                                % clear the command terminal

%% Import and plot sensor data
adrs='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\DataSim';
adr2='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\Code_Sim\CAR\Validation\Madgwick_Comp'
load([adrs, '/logfile_CAR_R01-2017_S4']);
RGB = imread('CAR.jpg');
addpath([adr2,'/common_func/']);
start=1
finish=20
[Acc1,Gyr1,Mag1,AHR1,WIFI1,BLE1,Lgh1,s_e_point]= path_data_split2(start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh);
Acc=Acc1;Gyr=Gyr1;Mag=Mag1;AHR=AHR1;  % AHR(:,1)>> pitch    AHR(:,2)>> Roll   AHR(:,3)>> Yaw
WIFI=WIFI1;BLE=BLE1;Lgh=Lgh1;
%% Heading from Madgwick
beta=0.08;
gyroMeasError=pi * (50 / 180)
beta=sqrt(3 / 4) * gyroMeasError;
zeta=0.016;
[ Heading_Madg, tim,phone_state]=Heading_Madgwick(Acc,Mag,Gyr,beta,zeta);

% PDR
%% step detection in each path
[StanceBegins_idx,time_step,Num_steps] = Step_Detection(Acc);
Step_events=StanceBegins_idx;
Timestep=time_step;
Step_event=Step_events;                          % number of samples that step is evented
Number_steps=length(Step_event);                 % number  of all steps
%% StepLenght estimation
K=0.33;
num_samples_Acc=size(Acc,1);
% 1) ACCe Magnitude
M_Acc=sqrt(Acc(:,1).^2+Acc(:,2).^2+Acc(:,3).^2);
% 2) Filter
tiempo_experimento=(Acc(end,4)-Acc(1,4));
num_acc_samples=size(Acc,1);                             % Acce samples
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
[b,a] = butter(4,3/freq_Acc,'low');
M_Acc=filtfilt(b,a,M_Acc);
% 3) Formula Analog Devices (Weiberg paper)  SL Estimation
sample_ini=1;
num_Step_events=length(Step_event);
for i=1:num_Step_events                    % for each of the steps detected
    sample_Step_event=Step_event(i);
    Acc_max(i)=max(M_Acc(sample_ini:sample_Step_event));
    Acc_min(i)=min(M_Acc(sample_ini:sample_Step_event));
    Bounce(i)=(Acc_max(i)-Acc_min(i))^(1/4);
    StrideLengths(i)=Bounce(i)*K*2;
    sample_ini= sample_Step_event;
end
%% heading in each step
for sn=1:size(Timestep,1)
    [~,dd]=min(abs(bsxfun(@minus, tim(1,:),...
        repmat( Timestep(sn),[1, size(tim,2)] ))));
    hse(sn)=dd;  % heading_sam_ekf
    
end

%% Destination from Madgwick Heading
p=Posi(:,3:4);                     % Posi ; 3 lat>0,  4 lon <0
R = 6371; % km
phi1_madg=deg2rad(p(start,1));       % lat 1 radian
lambda1_ekf= deg2rad(p(start,2));   % lon 1
ltLon_madg(1,1)=p(start,1);
ltLon_madg(1,2)=p(start,2);
latLon_g(1,1)=p(start,1);
latLon_g(1,2)=p(start,2);
gg=size(StrideLengths,2); % [1* ...]
for jj=1:gg
    dis=StrideLengths(1,jj);
    Bear_madg=Heading_Madg(1,hse(1,jj));
    c=dis/(R*1000);    % dis/R(in meter)
    phi_madg = asin( sin(phi1_madg)*cos(c) + sin(c)*cos(deg2rad(Bear_madg))*cos(phi1_madg));    % lat
    lambda_madg = lambda1_ekf +  atan2( sin(deg2rad(Bear_madg))* sin(c)* cos(phi1_madg), cos(c)- sin(phi1_madg)* sin(phi_madg));  % lon
    ltLon_madg(jj+1,1)=rad2deg(phi_madg);
    ltLon_madg(jj+1,2)=rad2deg(lambda_madg);
    phi1_madg=phi_madg;
    lambda1_ekf=lambda_madg;
    
end
latLon_madg= ltLon_madg;
clear ltLon_ekf
% lat lon to pixel
scale=0.05207600;                     % meter/pixel
lonX= -3.48367648;     % lon degree
latY= 40.31320308;     % lat
angle=-8.77680000;
[p_x p_y]=latlon2pixel(latLon_madg,RGB,angle,scale,lonX,latY);
PiXel_madg=[p_x;p_y];
[px py]=latlon2pixel(Posi(:,3:4),RGB,angle,scale,lonX,latY);
%% Plot
I = rgb2gray(RGB);
imshow(I)
hold on
plot(px,py,'o:')           % ref point
for i=1:size(px,2)
    text(px(1,i),py(1,i),num2str(i));
end
hold on
plot(PiXel_madg(1,:),PiXel_madg(2,:),'b.-','Linewidth',1)
axis auto
legend('Ref. point','Madgwick')
title('S4')
figure(2)
plot(phone_state.roll); hold on;  plot(phone_state.Pitch);hold on; plot(phone_state.yaw)
legend('roll','pitch','yaw')