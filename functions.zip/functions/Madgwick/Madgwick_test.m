close all;                          % close all figures
clear;                              % clear all variables
clc;                                % clear the command terminal

%% Import and plot sensor data
adrs='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\DataSim';
%load([adrs, '/logfile_CAR_R01-2017_S4']);
% start=8
% finish=11
% [Acc1,Gyr1,Mag1,AHR1,WIFI1,BLE1,Lgh1]= path_data_split2(start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh);
% Acc=Acc1;Gyr=Gyr1;Mag=Mag1;AHR=AHR1;  % AHR(:,1)>> pitch    AHR(:,2)>> Roll   AHR(:,3)>> Yaw
% WIFI=WIFI1;BLE=BLE1;Lgh=Lgh1;  

%%
load([adrs, '/ExampleData.mat']);

%% Process sensor data through algorithm
SamplePeriod=1/256;
Beta=0.1;
quaternion = zeros(length(time), 4);
Quaternion = [1 0 0 0];     % output quaternion describing the Earth relative to the sensor
for t = 1:length(time)
    Quaternion = Quaternion / norm(Quaternion); % normalise quaternion
    Qnb_u=Quaternion;
    Qnb_u=Qnb_u.*sign(Qnb_u(1));
    Acc=Accelerometer(t,:);
    Magn=Magnetometer(t,:);
    Gyro=Gyroscope(t,:)*pi/180 ;                % radian
    if(norm(Accelerometer) == 0), return; end	% handle NaN
    Acc = Acc / norm(Acc);                   	% normalise magnitude
    if(norm(Magnetometer) == 0), return; end	% handle NaN
    Magn = Magn / norm(Magn);	                % normalise magnitude
    % Reference direction of Earth's magnetic feild
    mag_qb=[0 Magn];
    conj_q=[Qnb_u(:,1) -Qnb_u(:,2) -Qnb_u(:,3) -Qnb_u(:,4)];
    a=mag_qb;
    b=conj_q;  % mag.q*
    ab(:,1) = a(:,1).*b(:,1)-a(:,2).*b(:,2)-a(:,3).*b(:,3)-a(:,4).*b(:,4);
    ab(:,2) = a(:,1).*b(:,2)+a(:,2).*b(:,1)+a(:,3).*b(:,4)-a(:,4).*b(:,3);
    ab(:,3) = a(:,1).*b(:,3)-a(:,2).*b(:,4)+a(:,3).*b(:,1)+a(:,4).*b(:,2);
    ab(:,4) = a(:,1).*b(:,4)+a(:,2).*b(:,3)-a(:,3).*b(:,2)+a(:,4).*b(:,1);
    a=Qnb_u;
    bb=ab;      % q.mag.q*
    h(:,1) = a(:,1).*bb(:,1)-a(:,2).*bb(:,2)-a(:,3).*bb(:,3)-a(:,4).*bb(:,4);
    h(:,2) = a(:,1).*bb(:,2)+a(:,2).*bb(:,1)+a(:,3).*bb(:,4)-a(:,4).*bb(:,3);
    h(:,3) = a(:,1).*bb(:,3)-a(:,2).*bb(:,4)+a(:,3).*bb(:,1)+a(:,4).*bb(:,2);
    h(:,4) = a(:,1).*bb(:,4)+a(:,2).*bb(:,3)-a(:,3).*bb(:,2)+a(:,4).*bb(:,1);
    
    M0 = [0 norm([h(2) h(3)]) 0 h(4)];
    % Gradient decent algorithm corrective step
    F = [2*(Qnb_u(2)*Qnb_u(4) - Qnb_u(1)*Qnb_u(3)) - Acc(1)
        2*(Qnb_u(1)*Qnb_u(2) + Qnb_u(3)*Qnb_u(4)) - Acc(2)
        2*(0.5 - Qnb_u(2)^2 - Qnb_u(3)^2) - Acc(3)
        2*M0(2)*(0.5 - Qnb_u(3)^2 - Qnb_u(4)^2) + 2*M0(4)*(Qnb_u(2)*Qnb_u(4) - Qnb_u(1)*Qnb_u(3)) - Magn(1)
        2*M0(2)*(Qnb_u(2)*Qnb_u(3) - Qnb_u(1)*Qnb_u(4)) + 2*M0(4)*(Qnb_u(1)*Qnb_u(2) + Qnb_u(3)*Qnb_u(4)) - Magn(2)
        2*M0(2)*(Qnb_u(1)*Qnb_u(3) + Qnb_u(2)*Qnb_u(4)) + 2*M0(4)*(0.5 - Qnb_u(2)^2 - Qnb_u(3)^2) - Magn(3)];
    J = [-2*Qnb_u(3),                 	2*Qnb_u(4),                    -2*Qnb_u(1),                         2*Qnb_u(2)
        2*Qnb_u(2),                 	2*Qnb_u(1),                    	2*Qnb_u(4),                         2*Qnb_u(3)
        0,                         -4*Qnb_u(2),                    -4*Qnb_u(3),                         0
        -2*M0(4)*Qnb_u(3),               2*M0(4)*Qnb_u(4),               -4*M0(2)*Qnb_u(3)-2*M0(4)*Qnb_u(1),       -4*M0(2)*Qnb_u(4)+2*M0(4)*Qnb_u(2)
        -2*M0(2)*Qnb_u(4)+2*M0(4)*Qnb_u(2),	2*M0(2)*Qnb_u(3)+2*M0(4)*Qnb_u(1),	2*M0(2)*Qnb_u(2)+2*M0(4)*Qnb_u(4),       -2*M0(2)*Qnb_u(1)+2*M0(4)*Qnb_u(3)
        2*M0(2)*Qnb_u(3),                2*M0(2)*Qnb_u(4)-4*M0(4)*Qnb_u(2),	2*M0(2)*Qnb_u(1)-4*M0(4)*Qnb_u(3),        2*M0(2)*Qnb_u(2)];
    step = (J'*F);
    step = step / norm(step);	% normalise step magnitude
    % Compute rate of change of quaternion
    %qDot = 0.5 * quaternProd(q, [0 Gyro(1) Gyro(2) Gyro(3)]) - Beta * step';
    
    a=Qnb_u;
    Gr_b=[0 Gyro];
    gq_Prod(:,1) = a(:,1).*Gr_b(:,1)-a(:,2).*Gr_b(:,2)-a(:,3).*Gr_b(:,3)-a(:,4).*Gr_b(:,4);
    gq_Prod(:,2) = a(:,1).*Gr_b(:,2)+a(:,2).*Gr_b(:,1)+a(:,3).*Gr_b(:,4)-a(:,4).*Gr_b(:,3);
    gq_Prod(:,3) = a(:,1).*Gr_b(:,3)-a(:,2).*Gr_b(:,4)+a(:,3).*Gr_b(:,1)+a(:,4).*Gr_b(:,2);
    gq_Prod(:,4) = a(:,1).*Gr_b(:,4)+a(:,2).*Gr_b(:,3)-a(:,3).*Gr_b(:,2)+a(:,4).*Gr_b(:,1);
    
    qDot=0.5*gq_Prod - Beta * step';
    
    % Integrate to yield quaternion
    Qnb_u = Qnb_u + qDot * SamplePeriod;
    Quaternion = Qnb_u / norm(Qnb_u); % normalise quaternion
    quaternion(t, :) = Quaternion;
end


%% 2 Euler

Qnb_u=[quaternion(:,1) -quaternion(:,2) -quaternion(:,3) -quaternion(:,4)];
R(1,1,:) = 2.*Qnb_u(:,1).^2-1+2.*Qnb_u(:,2).^2;
R(2,1,:) = 2.*(Qnb_u(:,2).*Qnb_u(:,3)-Qnb_u(:,1).*Qnb_u(:,4));
R(3,1,:) = 2.*(Qnb_u(:,2).*Qnb_u(:,4)+Qnb_u(:,1).*Qnb_u(:,3));
R(3,2,:) = 2.*(Qnb_u(:,3).*Qnb_u(:,4)-Qnb_u(:,1).*Qnb_u(:,2));
R(3,3,:) = 2.*Qnb_u(:,1).^2-1+2.*Qnb_u(:,4).^2;
% use conjugate for sensor frame relative to Earth and convert to degrees.
phi = atan2(R(3,2,:), R(3,3,:) );
theta = -atan(R(3,1,:) ./ sqrt(1-R(3,1,:).^2) );
psi = atan2(R(2,1,:), R(1,1,:) );

euler = [phi(1,:)' theta(1,:)' psi(1,:)'];
figure('Name', 'Euler Angles');
hold on;
plot(time, euler(:,1)* (180/pi), 'r');
plot(time, euler(:,2)* (180/pi), 'g');
plot(time, euler(:,3)* (180/pi), 'b');
title('Euler angles');
xlabel('Time (s)');
ylabel('Angle (deg)');
legend('\phi', '\theta', '\psi');
hold off;


