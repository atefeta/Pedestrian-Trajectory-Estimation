clc
clear all
close all
% Import data--------------------------------------------------------------
adrs='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\DataSim';
adr2='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\Code_Sim\CAR\Validation\Madgwick_Comp';
load([adrs, '/Wall_m']);%save('Wall_m')
addpath([adr2,'/common_func/']);addpath([adr2,'/Madgwick/']);
RGB_paint = imread('CAR_paint_control.jpg');load('controlpoint');% save('controlpoint')
%----- pixel to meter -----------------------------------------------------
scale=0.05207600; lonX= -3.48367648;latY= 40.31320308;angle=-8.77680000;[Xcent_m,Ycent_m]=ll2utm(latY,lonX);
[X_cp Y_cp]=pixel2Meter(controlpoint,RGB_paint,angle,scale,Xcent_m,Ycent_m);
clear RGB_paint;RGB_paint = imread('CAR_paint_refined.jpg');%imshow(RGB_paint)
% ----------------   lat lon 2 meter  -------------------------------------
Data=load([adrs, '/logfile_CAR_R04-2017_S4']);
[P0x P0y]=ll2utm([40.31320308 -3.48367648]);angle=-8.77680000;scale=0.05207600;% meter/pixel    % lon degree
ref_lat=Data.Posi(:,3);ref_lon=Data.Posi(:,4);[x,y]=ll2utm(ref_lat,ref_lon);
%%----------------- for each path between two ref. points -----------------
grayy=rgb2gray(RGB_paint);%imshow(grayy)(Data.Posi(1,1)-Data.Posi(end,1))/60
start=73
finish=74%A2_S4_42t43=estmated_path_LV';% estmated_path_LV(:,3)=Pdr_new(3,:)';
%A4_S5_73t74=Pdr_new;
%save('A4_S4_73t74')
%--------------------- OLD PDR estmated     -------------------------------
old_pdr=PDR_system(x,y,start,finish,Data.Acce,Data.Posi,Data.Gyro,Data.Magn,Data.Ahrs,Data.Wifi,Data.Ble4,Data.Ligh);
%---------------------  New PDR estmated    -------------------------------