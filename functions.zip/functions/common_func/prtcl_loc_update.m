function PLoc=prtcl_loc_update(ParLOC,teta,L)
xj_par=ParLOC(:,1)+(L*sin((teta)));
yj_par=ParLOC(:,2)+(L*cos((teta)));
PLoc=[xj_par yj_par ];
end