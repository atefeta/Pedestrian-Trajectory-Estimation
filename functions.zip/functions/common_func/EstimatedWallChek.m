function [onW, WCross]=EstimatedWallChek(EstLoc,PrevLoc,RGB_paint)

% EstLoc=LV(stp_id,1:2);PrevLoc=LV(stp_id-1,1:2);
onW = Wall_on_all(EstLoc,RGB_paint);
WCross = Wall_Crossing(EstLoc,PrevLoc,RGB_paint);
end