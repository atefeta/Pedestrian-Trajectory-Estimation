function ival=Dis_Part2Wallpoint(prtcl,maP,tr)
% prtcl=Particle;maP=Wall_m;
partclsize=size(prtcl,1);
for i=1:partclsize
% i=i+1
    part= ( repmat ( prtcl(i,:),size(maP,1) ,1));
    dif=part-maP;
    dif_2=dif.^2;
    sum_dif_2=sum( dif_2 ,2) ;
    Dis=sqrt(sum_dif_2);
    idx_w=find(Dis<=tr);
    if size(idx_w,1)~=0
        indexW{i}=i;
    else
        indexW{i}=0;
    end
    clear Dis sum_dif_2 dif_2 dif part idx_w
end
cat_w=cat(1,indexW{:});
ival=find(cat_w~=0);
end