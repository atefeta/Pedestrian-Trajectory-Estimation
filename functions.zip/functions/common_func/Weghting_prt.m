function W=Weghting_prt(PLoc,old,new,sp,alpha,L)
   % D:distance between particles and old pdr
   % d:distance between particles and new pdr
   D2old=sqrt( sum( (PLoc-repmat( old,sp,1)).^2,2 ));
   d2new=sqrt( sum( (PLoc-repmat( new,size(sp,1),1)).^2 ,2 ));
   D2old=D2old./L;
   d2new=d2new./L;
   coef=1./((alpha.*D2old)+((1-alpha).*d2new));
   sum_coef=sum(coef);
   W=coef./sum_coef;


end