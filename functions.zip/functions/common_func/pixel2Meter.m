function [X_m Y_m]=pixel2Meter(pixel_LoC,RGB,angle,scale,Xcent_m,Ycent_m)
I = rgb2gray(RGB);
pixel_wall=find(I<=255);I(pixel_wall)==0;
[rows columns] = size(I);
Ycent_p = ceil(rows / 2);
Xcent_p =ceil( columns / 2);
dangle=pi+deg2rad(angle);
dX_m=scale*(-pixel_LoC(:,1) + Xcent_p);
dY_m=scale*(pixel_LoC(:,2) - Ycent_p);
dXm=dX_m * -cos(deg2rad(angle)) - dY_m * sin(deg2rad(angle));
dYm=dX_m* sin(deg2rad(angle)) - dY_m * cos(deg2rad(angle));
X_m=dXm+Xcent_m;
Y_m=dYm+Ycent_m;

end