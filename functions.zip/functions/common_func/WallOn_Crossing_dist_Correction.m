function Particle_new=WallOn_Crossing_dist_Correction(id_cros,...
    Partc,On_waL,flG,onwaL_id,Wall_m)

% id_cros=id_cr;Partc=Prtcl_new;On_waL=On_wall;flG=flg;onwaL_id=id_onw
% (1) wall crossing correction   ----------------------------------------
if size(id_cros,2)~=0
    wcr_loc=Partc(id_cros' ,:);
    summask=On_waL+flG;
    vid=find(summask==0);
    if size(vid,2)~=0
        valid_loc=Partc(vid' ,:);
        pos_cr=Cross_2_closest(wcr_loc,valid_loc);
        Partc(id_cros' ,:)=pos_cr;
        clear wcr_loc pos_cr vid summask flg id_cr
    end
end
% (2) wall on correction  ------------------------------------------------
if size(onwaL_id,2)~=0
    onwall_prt=Partc(onwaL_id' ,:);
    nowall_id0=find(On_waL==0);
    nowall=Partc(nowall_id0' ,:);
    loc0=OnWall2closestpoint(onwall_prt,nowall);
    Partc(onwaL_id' ,:)=loc0;clear onwaL_id
end
% (3) ------------- distance correction ----------------------------------
idex_wdis=Dis_Part2Wallpoint(Partc,Wall_m,0.25);
if size(idex_wdis,1)~=0
    mask=zeros(size(Partc,1),1);mask(idex_wdis)=1;
    mask=mask.*(1:size(Partc,1))';
    walclos_loc=Partc(idex_wdis,:);
    valid_id=find(mask==0);
    valid_loc=Partc(valid_id,:);
    if size(valid_loc,1)~=0
        Pos_cls=Closewall_2_closest(walclos_loc,valid_loc) ;
        Partc(idex_wdis,:)=Pos_cls;
        clear walclos_loc idex_wdis  valid_loc mask Pos_cls
    end  
end
% ------------------------------------------------------------------------
Particle_new=Partc;
end