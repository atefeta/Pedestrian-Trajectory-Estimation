function onwall_f=Wall_on_all(particleS,RgB)
%RgB=RGB_paint;particleS=Prtcl_new;
scale=0.05207600;                     % meter/pixel
lonX= -3.48367648;     % lon degree
latY= 40.31320308;     % lat
angle=-8.77680000;
[P0x P0y]=ll2utm([40.31320308 -3.48367648]);
Map_gray=rgb2gray(RgB);% figure(3); imshow(Map_gray)
% pixel_wall=find(Map_gray<=255);Map_gray(pixel_wall)==0;
black=find(Map_gray < 30);Map_gray(black)=0;
for ix=1:size(particleS,1)
[x_pix y_pxl]=Meter2pixel([particleS(ix,1),particleS(ix,2)],RgB,angle,scale,P0x,P0y);
if (x_pix > size(Map_gray,2) || y_pxl>=size(Map_gray,1)...
        || x_pix < 1 ||  y_pxl<=1)
    onwall_f(ix)=0; % no wall
    continue
end
if Map_gray(y_pxl,x_pix) < 10 % is black >>>>> Wall detected
    onwall_f(ix)=1;
else
   onwall_f(ix)=0; 
end

end % for particles

end