
function [LOC,pdrOLD,SL_teta]=PDR_new(Old_pdr,Finish,x,y)
% Old_pdr=old_pdr;Finish=finish;x=x_ref;y=y_ref;
S_tim(1,1)=Old_pdr.stime;% start time
S_tim(1,2:size(Old_pdr.time,1)+1)=(Old_pdr.time)'; % step time
pdrOLD=[Old_pdr.coor';S_tim];% OLD(1,:)=start point
stepSize=size(Old_pdr.Sl,2);
ex=x(Finish)- Old_pdr.coor(end,1);
ey=y(Finish)- Old_pdr.coor(end,2);
% d=sqrt(ex^2 + ey^2)
sid=0;
t_start=pdrOLD(3,1);
t_ns=pdrOLD(3,end);
X0=pdrOLD(1:2,1);
for conteri=1:stepSize
    sid=sid+1;
    %a=sid/stepSize;
    ti=pdrOLD(3,sid+1); 
    a=( (ti-t_start)/(t_ns-t_start) )*(sid/stepSize);
    %a=sid/stepSize;
    newLOC(1,sid)=a*ex + pdrOLD(1,sid+1);
    newLOC(2,sid)=a*ey + pdrOLD(2,sid+1);
    dx=newLOC(1,sid)- X0(1,1);
    dy=newLOC(2,sid)-X0(2,1);
    Ltheta(1,sid)=atan2( dx , dy );
    Ltheta(2,sid)=sqrt( (dx)^2 + (dy)^2);
    X0=[newLOC(1,sid) ; newLOC(2,sid) ];
    
end
LOC(1:3,1)=pdrOLD(:,1); % start
LOC(1:2,2:stepSize+1)=newLOC;
LOC(3,:)=pdrOLD(3,:);
SL_teta=Ltheta;




end