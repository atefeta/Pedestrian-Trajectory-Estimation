function [BearQ_mg,bearQ_g,StrideLengths]=headingQ_SLenght(K,Acc,Mag,Gyr,Step_eventS,TimestepS,mag_help)
num_samples_Acc=size(Acc,1);% Step_eventS=Step_event;
% 1) ACCe Magnitude
M_Acc=sqrt(Acc(:,1).^2+Acc(:,2).^2+Acc(:,3).^2);
% 2) Filter
tiempo_experimento=(Acc(end,4)-Acc(1,4));
num_acc_samples=size(Acc,1);                             % Acce samples
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
[b,a] = butter(4,3/freq_Acc,'low');
M_Acc=filtfilt(b,a,M_Acc);
% 3) Formula Analog Devices (Weiberg paper)  SL Estimation
sample_ini=1;
StrideLengths=[];
num_Step_events=length(Step_eventS);
for i=1:num_Step_events                    % for each of the steps detected
    sample_Step_event=Step_eventS(i);
    Acc_max(i)=max(M_Acc(sample_ini:sample_Step_event));
    Acc_min(i)=min(M_Acc(sample_ini:sample_Step_event));
    Bounce(i)=(Acc_max(i)-Acc_min(i))^(1/4);
    StrideLengths(i)=Bounce(i)*K*2;
    sample_ini=sample_Step_event;
end
% 4) Thetas in each step from acc. and magn.
A= -309.8/1000;                  % X+ ==> East  micro tesla
B= 25657.3/1000;                 % Y+ ==> North micro tesla
D= -36694.9/1000;                % Z+ ==> Down micro tesla
% initialize Roll, Pitch, Yaw
ax=Acc(1,1);
ay=Acc(1,2);
az=Acc(1,3);
time_a=Acc(1,4);
[time_mag,magSam] = min(abs(bsxfun(@minus,Mag(:,4), repmat(Acc(1,4),[size(Mag(:,4),1),1]))));
mx=Mag(magSam,1);
my=Mag(magSam,2);
mz=Mag(magSam,3);
Rol=atan2(-ax , az);                   % rad
pitch=atan2(ay , sqrt(ax^2 + az^2) );  % rad
r_deg=rad2deg(Rol) ;                   % deg
p_deg=rad2deg(pitch)  ;                % deg
F=mx*cos(Rol)+mz*sin(Rol);
G=mx*sin(Rol)*sin(pitch) - mz*sin(pitch)*cos(Rol) + my*cos(pitch);
Yaw_rad=atan2( B*F-A*G , A*F+B*G );
Yaw_deg1=rad2deg(Yaw_rad);
Yaw_deg2=mod(Yaw_deg1+360 , 360 );
yaw_r=deg2rad(Yaw_deg2);
Yaw_ini=yaw_r;

if Acc(1,3)<4 & Acc(1,2)>3 % calling state detection
    Heading_mg=rad2deg(Rol)-90;
    yes=1
else
    Heading_mg=Yaw_deg1;
end

if Heading_mg<=0
    bearing_mg=-1*Heading_mg;
else
    bearing_mg=360-Heading_mg;
end
% 4) Thetas in each step
num_samples_Gyr=size(Gyr,1);
freq_Gyr=ceil(num_samples_Gyr/tiempo_experimento);       % mag samples/s o Hz
Rot_nb=zeros(3,3,num_samples_Acc);
Rot_z=[cos(Yaw_ini)  sin(Yaw_ini) 0; -sin(Yaw_ini) cos(Yaw_ini) 0; 0 0 1];        % from n-frame to b-frame
Rot_y=[cos(Rol) 0 -sin(Rol); 0 1 0;  sin(Rol)   0 cos(Rol)];                      % from n-frame to b-frame
Rot_x=[1 0 0; 0 cos(pitch)  sin(pitch); 0 -sin(pitch) cos(pitch)];                % from n-frame to b-frame
Rot_nb(:,:,1)=Rot_y(:,:)*Rot_x(:,:)*Rot_z(:,:);        % YXZ                           % from n-frame to b-frame
Rot_bnmg(:,:,1)=Rot_nb(:,:,1)';                                                                   % from b-frame to n-frame
Rot_bng(:,:,1)=Rot_nb(:,:,1)';
num_samples_Gyr=size(Gyr,1);
q_bng=DCM2Quaternion(Rot_bng(:,:,1));
q_bn_mg=DCM2Quaternion(Rot_bnmg(:,:,1));
%% Propagate the matrix Rotation to rest of samples with Gyrscope: i=i+1
for i=1:num_samples_Gyr
    time_gr(i)=Gyr(i,4);
    % Actualizar matriz de orientaci�n con valores de los "Gyrs"
    SkewGyrosQ=[0 -Gyr(i,1)  -Gyr(i,2)  -Gyr(i,3);...
        Gyr(i,1)  0   Gyr(i,3) -Gyr(i,2);...
        Gyr(i,2) -Gyr(i,3) 0  Gyr(i,1);...
        Gyr(i,3)  Gyr(i,2) -Gyr(i,1) 0]; % rad/s
    if i>1
        % Rot_bng(:,:,i)=Rot_bng(:,:,i-1)*expm(SkewGyrs/freq_Gyr);
        q_bng(:,1,i)=q_bng(:,1,i-1)+ ((0.5*SkewGyrosQ*q_bng(:,1,i-1))/freq_Gyr);
        q_bn_mg(:,1,i)=q_bn_mg(:,1,i-1)+ ((0.5*SkewGyrosQ*q_bn_mg(:,1,i-1))/freq_Gyr);      
        q_bng(:,1,i)= q_bng(:,1,i)/norm( q_bng(:,1,i));
        q_bng(:,1,i)=q_bng(:,1,i)*sign(q_bng(1,1,i));
        q_bn_mg(:,1,i)= q_bn_mg(:,1,i)/norm(q_bn_mg(:,1,i));
        q_bn_mg(:,1,i)=q_bn_mg(:,1,i)*sign(q_bn_mg(1,1,i));       
        if mod(i,freq_Gyr*mag_help)==0  % update with magnetometer each 2 s
            [~,ag_s] = min(abs(bsxfun(@minus,Acc(:,4), repmat(Gyr(i,4),[size(Acc(:,4),1),1]))));
            [~,mg_s] = min(abs(bsxfun(@minus,Mag(:,4), repmat(Gyr(i,4),[size(Mag(:,4),1),1]))));
            ax=Acc(ag_s ,1);
            ay=Acc(ag_s ,2);
            az=Acc(ag_s ,3);
            mx=Mag(mg_s ,1);
            my=Mag(mg_s ,2);
            mz=Mag(mg_s ,3);
            Rol=atan2(-ax , az);                   % rad
            pitch=atan2(ay , sqrt(ax^2 + az^2) );  % rad
            r_deg=rad2deg(Rol);                    % deg
            p_deg=rad2deg(pitch);                  % deg
            F=mx*cos(Rol)+mz*sin(Rol);
            G=mx*sin(Rol)*sin(pitch) - mz*sin(pitch)*cos(Rol) + my*cos(pitch);
            Yaw_rad=atan2( B*F-A*G , A*F+B*G );
            Rot_z=[cos(Yaw_rad)  sin(Yaw_rad) 0; -sin(Yaw_rad) cos(Yaw_rad) 0; 0 0 1];        % from n-frame to b-frame
            Rot_y=[cos(Rol) 0 -sin(Rol); 0 1 0;  sin(Rol)   0 cos(Rol)];                      % from n-frame to b-frame
            Rot_x=[1 0 0; 0 cos(pitch)  sin(pitch); 0 -sin(pitch) cos(pitch)];                % from n-frame to b-frame
            Rot_nb2=Rot_y(:,:)*Rot_x(:,:)*Rot_z(:,:);                                         % from n-frame to b-frame
            Rot_bnmg(:,:,i-1)=Rot_nb2';                                                       % from b-frame to n-frame
            q_bn_mg(:,1,i-1)=DCM2Quaternion(Rot_bnmg(:,:,i-1));                        
        end
        q_bn_mg(:,1,i)=q_bn_mg(:,1,i-1)+((0.5*SkewGyrosQ*q_bn_mg(:,1,i-1))/freq_Gyr);
        q_bn_mg(:,1,i)= q_bn_mg(:,1,i)/norm(q_bn_mg(:,1,i));
        q_bn_mg(:,1,i)=q_bn_mg(:,1,i)*sign(q_bn_mg(1,1,i));        
    end    
end
% split for each step
    for k=1:num_Step_events
        [~,step_event_gyr]=min(abs(bsxfun(@minus,Gyr(:,4), repmat(TimestepS(k),[size(Gyr(:,4),1),1]))));
        kk=step_event_gyr;
        R12=2*q_bn_mg(2,1,kk)*q_bn_mg(3,1,kk)-2*q_bn_mg(1,1,kk)*q_bn_mg(4,1,kk);
        R22=2*q_bn_mg(1,1,kk)^2 -1 + 2* q_bn_mg(3,1,kk)^2;
        yawQmg_rad(k)=-atan2(R12 ,R22 );
        yawQmg_degree(k)= rad2deg(yawQmg_rad(k));
        if yawQmg_degree(k)<=0
            BearingQ_Mg(k)=-1*yawQmg_degree(k);
        else
            BearingQ_Mg(k)=360-yawQmg_degree(k);
        end   
    end
    for k=1:num_Step_events
        [~,step_event_gyr]=min(abs(bsxfun(@minus,Gyr(:,4), repmat(TimestepS(k),[size(Gyr(:,4),1),1]))));
        kk=step_event_gyr;
        R12=2*q_bng(2,1,kk)*q_bng(3,1,kk)-2*q_bng(1,1,kk)*q_bng(4,1,kk);
        R22=2*q_bng(1,1,kk)^2 -1 + 2* q_bng(3,1,kk)^2;
        yawQg_rad(k)=-atan2(R12 ,R22 );
        yawQg_degree(k)= rad2deg(yawQg_rad(k));
        if yawQg_degree(k)<=0
            bearingQ_g(k)=-1*yawQg_degree(k);
        else
            bearingQ_g(k)=360-yawQg_degree(k);
        end  
    end   
    BearQ_mg=BearingQ_Mg;
    bearQ_g=bearingQ_g;

end