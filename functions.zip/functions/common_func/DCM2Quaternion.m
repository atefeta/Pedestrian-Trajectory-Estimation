
function [Q_vector]=DCM2Quaternion(R_Mat)
% from Rot_b2n to quaternion
m11= R_Mat(1,1,1);
m12= R_Mat(1,2,1);
m13= R_Mat(1,3,1);
m21= R_Mat(2,1,1);
m22= R_Mat(2,2,1);
m23= R_Mat(2,3,1);
m31= R_Mat(3,1,1);
m32= R_Mat(3,2,1);
m33= R_Mat(3,3,1);
tr = m11 + m22 + m33;
if (tr > 0)
    S = sqrt(tr+1.0) * 2; % S=4*qw
    q_bn(1,1) = 0.25 * S;
    q_bn(2,1) = (m32 - m23) / S;
    q_bn(3,1) = (m13 - m31) / S;
    q_bn(4,1) = (m21 - m12) / S;
elseif ( m11 > m22 & m11 > m33 )  % If the trace of the matrix is less than or equal to zero
    % then identify which major diagonal element has the greatest value
    S = sqrt(1.0 + m11 - m22 - m33) * 2; % S=4*q(2,1)
    q_bn(1,1) = (m32 - m23) / S;
    q_bn(2,1) = 0.25 * S;
    q_bn(3,1) = (m12 + m21) / S;
    q_bn(4,1) = (m13 + m31) / S;
elseif (m22 > m33)
    S = sqrt(1.0 + m22 - m11 - m33) * 2; % S=4*q(3,1)
    q_bn(1,1) = (m13 - m31) / S;
    q_bn(2,1) = (m12 + m21) / S;
    q_bn(3,1) = 0.25 * S;
    q_bn(4,1) = (m23 + m32) / S;
else
    S = sqrt(1.0 + m33 - m11 - m22) * 2; %// S=4*q(4,1)
    q_bn(1,1) = (m21 - m12) / S;
    q_bn(2,1) = (m13 + m31) / S;
    q_bn(3,1) = (m23 + m32) / S;
    q_bn(4,1) = 0.25 * S;
end
q_bn=q_bn(:,1)/norm( q_bn(:,1));
q_bn=q_bn*sign(q_bn(1,1));
Q_vector=q_bn;
end