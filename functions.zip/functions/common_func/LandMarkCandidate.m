function LM_candidate =LandMarkCandidate(s_Loc,XY_landmark,past_loc,PrticleS,nn)
X_LM=XY_landmark(:,1);
Y_LM=XY_landmark(:,2);
% dist. os recently step to all Landmarls  -------------------------------
Diff=[X_LM(:,1) Y_LM(:,1)]-repmat( past_loc(1:2,1)' , size(X_LM,1),1);
dist=sqrt(sum( (Diff).^2 ,2 )) ;
closest_LMsid=find(dist<=5);
closest_LMs=[X_LM(closest_LMsid,1) Y_LM(closest_LMsid,1)];
% angle of Closest Landmarks to start Location ---------------------------
Dif=closest_LMs - repmat( s_Loc(1:2,1)' , size(closest_LMs,1),1);
dist2start=sqrt(sum( (Dif).^2 ,2 )) ;
dx=closest_LMs(:,1) - repmat( s_Loc(1,1) , size(closest_LMs,1),1);
dy=closest_LMs(:,2) - repmat( s_Loc(2,1) , size(closest_LMs,1),1);
teta2start=atan2(dx,dy);
% angle of recently Loc. to start Location -------------------------------
dis_s2p=sqrt(sum( (s_Loc(1:2,1) - past_loc(1:2,1)).^2,1));
teta_s2p=atan2( past_loc(1,1) - s_Loc(1,1)  , past_loc(2,1) - s_Loc(2,1)   );
% Probability calculation ------------------------------------------------
prob_dis=exp( -.5*((dist2start - repmat(dis_s2p,size(dist2start,1),1)).^2) );
norm_prob_dis=prob_dis/sum(prob_dis);
prob_teta=exp( -.5*((teta2start - repmat(teta_s2p,size(dist2start,1),1)).^2) );
norm_prob_teta=prob_teta/sum(prob_teta);
Prob_final=norm_prob_teta.*norm_prob_dis;
% Final Candidate Landmark ---------------------------------------------------
[~ ,id_max]=max(Prob_final);
LM_candidate=[closest_LMs(id_max,1),closest_LMs(id_max,2)];

end