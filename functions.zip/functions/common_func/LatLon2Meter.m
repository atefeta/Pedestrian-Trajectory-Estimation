clc;
clear all;
close all;
adrs='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\DataSim';
load([adrs, '/logfile_CAR_R01-2017_S4']);

% lat_deg=Posi(1,3)
% lon_deg=Posi(1,4)
% x1=4861677.70432523%  m
% y1=-295917.919020355  % m
% z1=4104939.30313624 %  m
% z1=0
% X2=4861688.66914679 %  m
% Y2=-295915.856738779  % m
% Z2=4104926.55153218%  m
% Z2=0;
% distance=sqrt( (x1-X2)^2 + (y1-Y2)^2 + (z1-Z2)^2) % 16.4012
% 
% dbiz=sqrt( (x1-X2)^2 + (y1-Y2)^2 )
LAT=Posi(:,3);
LON=Posi(:,4);

[X,Y]=ll2utm(LAT,LON); % or LL2UTM([LAT,LON]) converts coordinates  LAT,LON (in degrees) to UTM X and Y (in meters)
% plot(X,Y,'o:')
% % y32=Y(1)-Y(2)
% for i=1:size(X,1)-1
%    disutm(i)=sqrt( (X(i)-X(i+1))^2 + (Y(i)-Y(i+1))^2 ); 
% end
RGB = imread('CAR_paint_refined.jpg');
scale=0.05207600;      % meter/pixel
lonX= -3.48367648;     % lon degree of image center
latY= 40.31320308;     % lat
[Px0,Py0]=ll2utm(latY,lonX);% center of image to utm (meter)
angle=-8.77680000; % deg
I = rgb2gray(RGB);
[rows columns] = size(I);
y_center = rows / 2;
x_center = columns / 2;
dangle=pi+deg2rad(angle);
for i=1:size(X,1)
    dy=Y(i)- Py0;
    dx=X(i)- Px0;
    dX=dx * cos(dangle) - dy * sin(dangle);
    dY=dx* sin(dangle) + dy * cos(dangle);
    XY_pxl(i,1)=ceil( x_center - ( dX/scale));
    XY_pxl(i,2)=ceil( y_center + ( dY/scale));  %y
    
end


%% Plot

imshow(I)
hold on
plot(XY_pxl(:,1),XY_pxl(:,2),'o:')
axis auto
figure(2)
plot(XY_pxl(:,1),XY_pxl(:,2),'o:')























