function Position=Cross_2_closest(cr_loc,val_loc)
s=size(val_loc,1);
e=0.05;
for p=1:size(cr_loc,1)
    dis=sqrt( sum( (repmat(cr_loc(p,:),s,1)-val_loc).^2 ,2));
    [val,id]=min(dis);
    Position(p,1:2)=val_loc(id,:)-e;
    
    clear dis val id
end

end