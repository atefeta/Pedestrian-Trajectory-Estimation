function [X_px Y_py]=Meter2pixel(LoC,RGB,angle,scale,P0X,P0Y)

dangle=pi+deg2rad(angle);
I = rgb2gray(RGB);
[rows columns] = size(I);
y_center = rows / 2;
x_center = columns / 2;
for i=1:size(LoC,1)
    dy=LoC(i,2)- P0Y;
    dx=LoC(i,1)- P0X;
    dX=dx * cos(dangle) - dy * sin(dangle);
    dY=dx* sin(dangle) + dy * cos(dangle);
    XY_pxl(i,1)=ceil( x_center - ( dX/scale));
    XY_pxl(i,2)=ceil( y_center + ( dY/scale));  %y
    
end
X_px=XY_pxl(:,1);
Y_py=XY_pxl(:,2);
end