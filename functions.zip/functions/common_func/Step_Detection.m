function [StanceBegins_idx,time_step,Num_steps] = Step_Detection(Acc)

num_acc_samples=size(Acc,1);
tiempo_experimento=(Acc(end,4)-Acc(1,4));                % time of elapsed for measurement (m)
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o H
Acc_mag=sqrt(Acc(:,1).^2+Acc(:,2).^2+Acc(:,3).^2); 
% magnitude of Acc
order_filter=4;                                          % filter order
[b,a] = butter(order_filter,2/(freq_Acc/2),'low');       % Lowpass filter
[Acc_mag_filt,zf]=filter(b,a,Acc_mag);
[Acc_mag_filt,~]=filter(b,a,Acc_mag,zf);
varAcc=var(Acc_mag_filt);
sqr_varAcc=sqrt(varAcc); 
umbral_Acc=0.34;             % threshold  S4mini=0.4 m/s^2  s4=0.4
umbral_Acc_descarte=2;    % umbral=threshold greater than s4mini=1.5 m / s ^ 2 indicating excessive wiggle S4=2, A5=1.5
gravity=9.8;
Acc_filt_binary=zeros(1,length(Acc));
Acc_filt_detrend=zeros(1,length(Acc));
for ii=2:length(Acc)
    gravity=0.999*gravity+0.001*Acc_mag(ii);       % I calculate gravity experimentally (because in S3 I get 9.7 instead of expected which is 9.8)
    Acc_filt_detrend(ii)=Acc_mag_filt(ii)-gravity; % remove gravity
    if Acc_filt_detrend(ii)>umbral_Acc && Acc_filt_detrend(ii)<umbral_Acc_descarte
        Acc_filt_binary(ii)=1;                     % phases of rise of the body (start step), I put"1"
    else
        if Acc_filt_detrend(ii)<-umbral_Acc
            if Acc_filt_binary(ii-1)==1 % si despues de un "1" no hubiese un valor intermedio para generar el "0" entonces se lo pongo de manera forzada
                Acc_filt_binary(ii)=0;
            else  % caso normal: ya he puesto el "1", luego en "0", y ahora el "-1"
                Acc_filt_binary(ii)=-1; % fases de bajada del cuerpo (fin paso)
            end
        else
            Acc_filt_binary(ii)=0; % si est� entre el umbral superior y el inferior => lo marco con "0"
        end
    end
    
end
testt(1,:)=Acc_filt_detrend;
testt(2,:)= Acc_filt_binary;
stepcount=0;
StanceBegins_idx=[];                                   % time of step event
StepDect=zeros(1,length(Acc));
steps=zeros(1,length(Acc))*NaN;
window=ceil(0.4*freq_Acc);                             % Samples in window to consider 0.4 seconds
for ii=(window+2):length(Acc)
    % I detect steps if:
    if ( Acc_filt_binary(ii)==-1  && Acc_filt_binary(ii-1)==0  && (sum(Acc_filt_binary(ii-window:ii-2))>1 ))
        StepDect(ii)=1;
        stepcount=stepcount+1; % counter of steps
        StanceBegins_idx(stepcount)=ii;% acc sample number
        
    end
    if StepDect(ii)
        steps(ii)=0;
    else
        steps(ii)=NaN;
    end
end
% All the support samples
StancePhase=zeros(num_acc_samples,1);
for ii=StanceBegins_idx
    StancePhase(ii:ii+9,1)=ones(10,1);
    % I assume that the support phase is the next 10 samples at the beginning of the support phase (StanceBegins_idx)
end
% Calculation parameters:

time_step=Acc(StanceBegins_idx,4);      
Num_steps=length(StanceBegins_idx);              % number  of all steps



end