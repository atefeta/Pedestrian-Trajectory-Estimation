function [condid_loc new_loc] =Corected_Loc2(s_Loc,SL_teta,XY_cp,past_loc,PrticleS,nn)
%[cond_loc, est_cont_LV]=Corected_Loc([X_cp Y_cp],Est_LVar(stp_id,1:2),Prtcl_new,1);
X_cL=XY_cp(:,1);
Y_cL=XY_cp(:,2);
Diff=[X_cL(:,1) Y_cL(:,1)]-repmat( past_loc(1:2,1)' , size(X_cL,1),1);
dist=sqrt(sum( (Diff).^2 ,2 )) ;
[s_val,sort_id]=sort(dist);
closest_cont=find(dist<=5);
closest_Locs=[X_cL(closest_cont,1) Y_cL(closest_cont,1)];

Dif=closest_Locs-repmat( s_Loc(1:2,1)' , size(closest_Locs,1),1);
dist2start=sqrt(sum( (Dif).^2 ,2 )) ;
dx=closest_Locs(:,1) - repmat( s_Loc(1,1) , size(closest_Locs,1),1);
dy=closest_Locs(:,2) - repmat( s_Loc(2,1) , size(closest_Locs,1),1);
teta2start=atan2(dx,dy);

dis_s2p=sqrt(sum( (s_Loc(1:2,1) - past_loc(1:2,1)).^2,1));
teta_s2p=atan2( past_loc(1,1) - s_Loc(1,1)  , past_loc(2,1) - s_Loc(2,1)   );

prob_dis=exp( -.5*((dist2start - repmat(dis_s2p,size(dist2start,1),1)).^2) );
norm_prob_dis=prob_dis/sum(prob_dis);
[~,iid]=max(norm_prob_dis);
prob_teta=exp( -.5*((teta2start - repmat(teta_s2p,size(dist2start,1),1)).^2) );
norm_prob_teta=prob_teta/sum(prob_teta);
Prob_final=norm_prob_teta.*norm_prob_dis;
[~ ,id_max]=max(Prob_final);
new_loc_cntrl=[closest_Locs(id_max,1),closest_Locs(id_max,2)];
%PrticleS=Prtcl_new;

% new weighting closest particle to control point
Diff2c=PrticleS-repmat( new_loc_cntrl , size(PrticleS,1),1);
distocp=sqrt(sum( (Diff2c).^2 ,2 )) ;
[ val,mindis_id]=sort(distocp);% min to max
cand_loc=PrticleS(mindis_id(1:nn),:);
new_loc=sum(cand_loc,1)./nn;
condid_loc=new_loc_cntrl;

% plot(s_Loc(1,1),s_Loc(2,1),'o')
% hold on;plot(closest_Locs(:,1),closest_Locs(:,2),'*')
% hold on;plot(past_loc(1,1),past_loc(2,1),'gs')
% hold on;plot(X_cp(:,1),Y_cp(:,1),'.')
% hold on;plot(closest_Locs(id_max,1),closest_Locs(id_max,2),'^')


end