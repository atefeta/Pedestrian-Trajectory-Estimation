function [X] = lowVarianceRS(X0, weight, M0)
%X0 , weight=W; M0=size(Prtcl_new,1)
    X = zeros(1,M0);                  % Initialize empty set of particles
    %r = 0 + (M0^-1+0)*rand(1,1) r = a + (b-a).*rand(N,1). (a,b)
    r = 0 + (M0^-1+0)*rand(1,1);              % Select random number between 0-M^-1
    w = weight(1) ;                  % Initial weight
    i = 1 ;
    j = 1 ;

    for m = 1:M0
        U = r + (m - 1)/M0 ;          % Index of original sample + size^-1
        while U > w                 
            i = i + 1 ;
            w = w + weight(i); 
        end
        X(j) = X0(i) ;               % Add selected sample to resampled array
        j = j + 1 ;
    end
end