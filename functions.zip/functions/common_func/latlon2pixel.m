function [Lon_pxl Lat_pxl]=latlon2pixel(latLon3,RGB,angle,scale,lonX,latY)

I = rgb2gray(RGB);
[rows columns] = size(I);
y_center = rows / 2;
x_center = columns / 2;
dangle=pi+deg2rad(angle);
pX=x_center;
pY=y_center;
for i=1:size(latLon3,1)
    d_lat=latLon3(i,1)- latY;
    d_lon=latLon3(i,2)- lonX;
    ny=d_lat * 111111;
    nx=d_lon * (111111 * cos( deg2rad(latY)));
    X=nx * cos(dangle) - ny * sin(dangle);
    Y=nx* sin(dangle) + ny * cos(dangle);
    Lon_pxl(i)=ceil( pX - ( X/scale));
    Lat_pxl(i)=ceil( pY + ( Y/scale));
end


end