function Position=Closewall_2_closest(walclos_loc,valid_loc)
s=size(valid_loc,1);
for pi=1:size(walclos_loc,1)
    dis=sqrt( sum( (repmat(walclos_loc(pi,:),s,1)-valid_loc).^2 ,2));
    [val,id]=min(dis);
    Position(pi,1:2)=valid_loc(id,:)+0.1*rand(1);
    
    clear dis val id
end

end