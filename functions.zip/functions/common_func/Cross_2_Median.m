function loc_cr=Cross_2_Median(wcr_prt,valid_loc)

s=size(wcr_prt,1);
sr=size(valid_loc,1);

if sr==0
    loc_cr=wcr_prt;
else
    for prt=1:s
        a= repmat(wcr_prt(prt,1:2),sr,1);
        dis=sqrt(sum((a-valid_loc).^2 ,2));
        val = median(dis);
        [mval,mid]= min(abs(repmat(val ,sr ,1)-dis));
        loc_cr(prt,:)=valid_loc(mid,:)-0.1*rand(1);
end
end

end