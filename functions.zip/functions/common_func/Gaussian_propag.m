function apml=Gaussian_propag(Mu,sigma,N)
% Mu = [1 1];          % Mean of the 1st component
% sigma=0.07
% N=250
rng('default');
sigma1 = [sigma 0; 0 sigma]; % Covariance 
apml = mvnrnd(Mu,sigma1,N);
% scatter(r1(:,1),r1(:,2),'.') 

end

% mu = [0 0];
% sigma = [2 0; 0 2];
% rng default  % For reproducibility
% R = mvnrnd(mu,sigma,200);
% figure(2)
% plot(R(:,1),R(:,2),'+')