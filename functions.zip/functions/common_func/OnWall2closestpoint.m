function on_wall_prt=OnWall2closestpoint(onwall_prt,nowall)
s=size(nowall,1);
for prt=1:size(onwall_prt,1)
   a= repmat(onwall_prt(prt,1:2),s,1);
    dis=sqrt(sum((a-nowall).^2 ,2));
   [val id]= min(dis);
   on_wall_prt(prt,:)=nowall(id,:)-0.1*rand(1);
    
end
end