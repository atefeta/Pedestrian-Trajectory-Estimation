
function pdr_old=PDR_system_A5(X,Y,start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh)

% X=x_refm;Y=y_refm;start=start1;finish=finish1;Acce=Data.Acce;Magn=Data.Magn;
% Ahrs=Data.Ahrs;Wifi=Data.Wifi;Ble4=Data.Ble4;Ligh=Data.Ligh;Posi=Data.Posi;Gyro=Data.Gyro;
[Acc1,Gyr1,Mag1,AHR1,WIFI1,BLE1,Lgh1,s_e_point,stim,ftim]= path_data_split2(start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh);
Acc=Acc1;Gyr=Gyr1;Mag=Mag1;AHR=AHR1;


%% step detection in each path
[StanceBegins_idx,time_step,Num_steps] = Step_Detection(Acc);
Step_events=StanceBegins_idx;Timestep=time_step;
Step_event=Step_events;% number of samples that step is evented                        
Number_steps=length(Step_event);  
%% Heading StepLenght estimation from mag
K=0.3;
[bearing_M ,SLengths]=headingMag_SLenght(K,Acc,Mag,Step_event,Timestep);
%% Destination from Madgwick Heading
SL=SLengths;
gg=size(SL,2);
x_y(1,1)=X(start);
x_y(1,2)=Y(start);
for j=1:gg
    teta(j)=bearing_M(j);%Heading_Madg(1,hse(1,j)); % teta: angle to geo. north axis
    x_y(j+1,1)=x_y(j,1)+(SL(1,j)*sin(deg2rad( teta(j))));
    x_y(j+1,2)=x_y(j,2)+(SL(1,j)*cos(deg2rad(teta(j))));
end
pdr_old.coor=x_y;
pdr_old.time=time_step;
pdr_old.tetha=teta;
pdr_old.Sl=SL;
pdr_old.stime=stim;
end






  













