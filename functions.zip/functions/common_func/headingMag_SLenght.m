function [bearing_m ,SLen,pitch,ROll,YAW]=headingMag_SLenght(K,Accc,Magg,Step_eventS,TimestepS)
% Accc=Acc;Magg=Mag;Step_eventS=Step_event;TimestepS=Timestep;

num_samples_Acc=size(Accc,1);
% 1) ACCe Magnitude
M_Acc=sqrt(Accc(:,1).^2+Accc(:,2).^2+Accc(:,3).^2);
% 2) Filter
tiempo_experimento=(Accc(end,4)-Accc(1,4));
num_acc_samples=size(Accc,1);                             % Acce samples
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
[b,a] = butter(4,3/freq_Acc,'low');
M_Acc=filtfilt(b,a,M_Acc);
% 3) Formula Analog Devices (Weiberg paper)
sample_ini=1;
StrideLengths=[];
num_Step_eventSs=length(Step_eventS);
for i=1:num_Step_eventSs                    % for each of the steps detected
    sample_Step_eventS=Step_eventS(i);
    Acc_max(i)=max(M_Acc(sample_ini:sample_Step_eventS));
    Acc_min(i)=min(M_Acc(sample_ini:sample_Step_eventS));
    Bounce(i)=(Acc_max(i)-Acc_min(i))^(1/4);
    StrideLengths(i)=Bounce(i)*K*2;
    sample_ini=sample_Step_eventS;
end
% 4) Thetas in each step from acc. and magn.
A= -303.9/1000;                  % X+ ==> East  micro tesla
B= 25657.3/1000;                 % Y+ ==> North micro tesla
D= -36694.9/1000;                % Z+ ==> Down micro tesla
num_acc_samples=size(Accc,1);                             % Acce samples
num_samples_mag=size(Magg,1);
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
freq_Mag=ceil(num_samples_mag/tiempo_experimento);       % mag samples/s o Hz
step_acc_time=Accc(Step_eventS,4);
Step_eventS_mag1=ceil((Step_eventS.*freq_Mag)./freq_Acc);
% based Time 
for ti=1:size(TimestepS,1)
    dist=abs(repmat(TimestepS(ti,1),size(Magg,1),1)-Magg(:,4));
    [mv minId]=min(dist);clear dist
    Step_eventS_mag2(1,ti)=minId;clear minId mv
end
% % % 
Step_eventS_mag=Step_eventS_mag2;

% t=t+1
for t=1:size(Step_eventS,2)
    ax=Accc(Step_eventS(1,t),1);
    ay=Accc(Step_eventS(1,t),2);
    az=Accc(Step_eventS(1,t),3);
    mx=Magg(Step_eventS_mag(1,t),1);
    my=Magg(Step_eventS_mag(1,t),2);
    mz=Magg(Step_eventS_mag(1,t),3);
    Rol=atan2(-ax , az);                   % rad
    pitch=atan2(ay , sqrt(ax^2 + az^2) );  % rad
    r_deg(t,1)=rad2deg(Rol);r_deg(t,2)=mod(r_deg(t,1)+360 , 360 );                     % deg
    p_deg(t,1)=rad2deg(pitch);p_deg(t,2)=mod(p_deg(t,1)+360 , 360 );                   % deg
    F=mx*cos(Rol)+mz*sin(Rol);
    G=mx*sin(Rol)*sin(pitch) - mz*sin(pitch)*cos(Rol) + my*cos(pitch);
    Yaw_rad=atan2( B*F-A*G , A*F+B*G );
    Yaw_deg(t,1)=rad2deg(Yaw_rad);
    Yaw_deg(t,2)=mod(Yaw_deg(t,1)+360 , 360 );  
    
    
    if (r_deg(t,1)<=-74 )&& (r_deg(t,1)>=-100)&&(Yaw_deg(t,1)<=29)&&(Yaw_deg(t,1)>=-9) && (p_deg(t,1)<= 56)&&(p_deg(t,1)>=30)
        azim(t,1:2)=r_deg(t,:);
        if azim(t,1)<=0
            bearing_m(t,1)=-1*azim(t,1)+90;
            
        else
            bearing_m(t,1)=360-azim(t,2)+90;
            
        end
        
    else
        azim(t,1:2)=Yaw_deg(t,:);
        if azim(t,1)<=0
            bearing_m(t,1)=-1*azim(t,1);
            
        else
            bearing_m(t,1)=360-azim(t,2);
            
        end
    end
    
    
    
    %     if Yaw_deg(t,1)<=0
    %         bearing_m(t,1)=-1*Yaw_deg(t,1);
    %     else
    %         bearing_m(t,1)=360-Yaw_deg(t,2);
    %     end
    
%     if r_deg(t,1)<=0
%         bearing_m(t,1)=-1*r_deg(t,1)+90;
%     else
%         bearing_m(t,1)=360-r_deg(t,2)+90;
%     end
end

SLen=StrideLengths;

pitch=p_deg;
ROll=r_deg;
YAW=Yaw_deg;
end