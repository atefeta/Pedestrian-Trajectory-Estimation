clc;clear all;close all
%% Add Pathes and Load Data ------------------------------------------------
rng('default');
adrs='E:\Research_for_ThesiS\ATF_Simulation_Code\IPIN_Competition\IPIN 2017\DataSim';
adr2='E:\Research_for_ThesiS\ATF_Thesis_Code';
addpath([adr2,'/common_func/']);addpath([adr2,'/Madgwick/']);addpath([adr2,'/MatData/']);
addpath([adr2,'/MapImages/']);addpath([adr2,'/DTW/']);
load([adrs, '/Wall_m']);load('PathN_pxm');load('controlpoint');
load('MatrixGraph');load('PathSs');load('controlpoint');
RGB_paint = imread('CAR_paint_control.jpg');
ColoredMap=imread('MapSubSection.jpg');%imshow(ColoredMap)
Data=load([adrs, '/logfile_CAR_R01-2017_S4']);
KP=1;% KP path candidate
befor_coef=1;
% Ref. Coordinate lat lon 2 meter  ---------------------------------------
[x_refm,y_refm]=ll2utm(Data.Posi(:,3),Data.Posi(:,4));
% pixel to meter of control point ----------------------------------------
[Xcent_m,Ycent_m]=ll2utm(40.31320308,-3.48367648);scale=0.05207600;angle=-8.77680000;
[X_cp Y_cp]=pixel2Meter(controlpoint,RGB_paint,angle,scale,Xcent_m,Ycent_m);
clear RGB_paint;RGB_paint = imread('CAR_paint_refined.jpg');
% OLD PDR for each path between two ref. points --------------------------
start=1
finish=5
old_pdr=PDR_system(x_refm,y_refm,start,finish,Data.Acce,Data.Posi,Data.Gyro...
                    ,Data.Magn,Data.Ahrs,Data.Wifi,Data.Ble4,Data.Ligh);
% New PDR estmated -------------------------------------------------------
[Pdr_new, OLD,SL_teta]=PDR_new(old_pdr,finish,x_refm,y_refm);
PDR_NEW_orginal=Pdr_new;
PDR_old_orginal=OLD;
% Plot Wall,Ref., Old Pdr and New Pdr
plot(Wall_m(:,1),Wall_m(:,2),'.','MarkerSize',4);hold on;
plot(x_refm,y_refm,'o:','MarkerSize',3);hold on
%plot(PDR_old_orginal(1,:),PDR_old_orginal(2,:),'m.-','MarkerSize',4);hold on
plot(Pdr_new(1,:),Pdr_new(2,:),'k.-','MarkerSize',4);hold on
for i=1:size(x_refm,1)
    text(x_refm(i,1),y_refm(i,1),num2str(i),'FontSize',8,'Color','k');
end;hold on;plot(X_cp(:,1), Y_cp(:,1),'g*')
% Start Particle Filter --------------------------------------------------
% (0) initializing
alpha=.5; % fusion coef  >>>>  1/(a(D2old)+(1-a)d2new)
var=.6;np=50;mu =[Pdr_new(1,1) Pdr_new(2,1)];%variance, part num, mean
Particle=Gaussian_propag(mu,var,np);%Gaussian point generation
Particle=Inithial_corrected_particle(Particle,mu,RGB_paint,Wall_m);clear mu;%hold on;plot(Particle(:,1),Particle(:,2),'.')
%% ----------------------   PF Loop  --------------------------------------
for stp_id=1:76%size(old_pdr.Sl,2) % for all step detected on current path
    stp_id % stp_id=stp_id+1
    % hold on; plot(Pdr_new(1,stp_id+1),Pdr_new(2,stp_id+1),'ko')
%>>>-------------- new location based observation ----------------------
    Prtcl_new=prtcl_loc_update(Particle,SL_teta(1,stp_id),SL_teta(2,stp_id));
%hold on; plot(Prtcl_new(:,1),Prtcl_new(:,2),'.')
    % ----------  Observation Error Detection ( wall crossing + on wall) ------
    On_wall = Wall_on_all(Prtcl_new,RGB_paint);id_onw = find(On_wall==1);%OnWallDetection
    for jj=1:size(Prtcl_new,1) % Wall crossing test 
        flg(jj)=Wall_Crossing(Prtcl_new(jj,:),Particle(jj,:),RGB_paint);
    end;  id_cr=find(flg==1);
    sum_mask=On_wall+flg;
    invalid_particle(stp_id,1)=size(find(sum_mask~=0),2);clear sum_mask
    er_invalid_State(stp_id,1)=invalid_particle(stp_id,1)/size(Prtcl_new,1);   
% ----------  Observation Error Correction --------------------------------
    if er_invalid_State(stp_id,1)<=0.8 && invalid_particle(stp_id,1)~=0
        %  wallcrossing-onwall-dist2Wall correction
        wallcorrection_is_apply=1
        % id_cros, Partc,On_waL,flG,onwaL_id,Wall_m
        Particle_new=WallOn_Crossing_dist_Correction(id_cr,Prtcl_new,On_wall,flg,id_onw,Wall_m);
        Prtcl_new=Particle_new;clear Particle_new
         %hold on;plot(Prtcl_new(:,1),Prtcl_new(:,2),'.')
    elseif er_invalid_State(stp_id,1)>0.8
% -----------  Path and Point Matching  ----------------------------------
%  (1) Point selection by Path Finding
        pathFindind_is_apply=1
        [ DIST1, K_PATH,Dist2, uniq_PATH ]=pathcandidate(Pdr_new,PathN_pxm,MatrixGraph,KP);
        % DTW algorithim for Loc finding ----------
        pathFind_nd=PathN_pxm(uniq_PATH',5:6);
        %pathFind_mtr=PathN_pxm(uniq_PATH',1:2);
        hold on;plot(pathFind_nd(:,1),pathFind_nd(:,2),'.');hold on
        PathMatched=DTW_Pathmatching(Pdr_new(1:2,1:stp_id)',pathFind_nd);
        pathCand_id=find(PathMatched.NoWind(:,2)==stp_id);% cosin Sim
        NewLocID=PathMatched.NoWind(pathCand_id(1),1);
        SujestedLoc=[pathFind_nd(NewLocID,1),pathFind_nd(NewLocID,2)];clear NewLocID
        plot(SujestedLoc(1,1),SujestedLoc(1,2),'cs');hold on
        %  (2) Point selection by door crossing Cheking
        %  (3) Final Point Calculation For Refining of path
        locSelect=PointSelection(Pdr_new(1:2,stp_id+1)',Pdr_new(1:2,stp_id)',SujestedLoc,RGB_paint);
        % hold on;plot(locSelect(1,1),locSelect(1,2),'ch')
        %  (4) path correction
        [LOCnew,Lthetanew]=CorectedPathMM(locSelect,stp_id,Pdr_new,befor_coef);
        hold on;plot(LOCnew(1,:),LOCnew(2,:),'r.');drawnow;
        OLD=Pdr_new;clear Pdr_new
        Pdr_new=LOCnew;
        SL_teta=Lthetanew;
        %  (5) new Particles Location calculation -------------------------
        Particle=Gaussian_propag(locSelect,var,np);%Gaussian point generation
        Particle=Inithial_corrected_particle(Particle,locSelect,RGB_paint,Wall_m);
        Prtcl_new=Particle;
    end % er_invalid_State(stp_id,1)>0.8
% End Path Matching ------------------------------------------------------
%>>>--------------- Weighting and Estimation Step ------------------------
    W=Weghting_prt(Prtcl_new,OLD(1:2,stp_id+1)',Pdr_new(1:2,stp_id+1)'...
        ,size(Prtcl_new,1),alpha,old_pdr.Sl(1,stp_id));
%----- Low variance resampling and Estimated Loc ----------------------
    index_rs = lowVarianceRS(1:size(Prtcl_new,1) , W, size(Prtcl_new,1));
    p_lv=Prtcl_new(index_rs',:);
    Est_LVar(stp_id,1:2)=(sum(p_lv,1))/size(p_lv,1);
    LVest(stp_id,1:2)=Est_LVar(stp_id,1:2);
    clear index_rs p_lv
    Particle=Prtcl_new;clear Prtcl_new
    drawnow
    hold on;plot(LVest(stp_id,1),LVest(stp_id,2),'c.');
    %hold on;plot(LVest(:,1),LVest(:,2),'co');
% Estimation Error cheking and Correction --------------------------------
% on Wall or Wall crossing Cheking ---------------------------------------
if stp_id~=1
    [onW, WCross]=EstimatedWallChek(LVest(stp_id,1:2),LVest(stp_id-1,1:2),RGB_paint);
elseif stp_id==1
    [onW, WCross]=EstimatedWallChek(LVest(stp_id,1:2),Pdr_new(1:2,1)',RGB_paint);
end
if onW==1 || WCross==1
    Error_in_PF_est=1
    % Corrected Loc and Path Calculation
    [ DIST12, K_PATH2,Dist22, uniq_PATH2 ]=pathcandidate(Pdr_new,PathN_pxm,MatrixGraph,KP);
    % DTW algorithim for Loc finding ----------
    pathFind_nd2=PathN_pxm(uniq_PATH2',5:6);
    hold on;plot(pathFind_nd2(:,1),pathFind_nd2(:,2),'.');hold on
    PathMatched2=DTW_Pathmatching(Pdr_new(1:2,1:stp_id)',pathFind_nd2);
    pathCand_id2=find(PathMatched2.NoWind(:,2)==stp_id);% cosin Sim
    NewLocID=PathMatched2.NoWind(pathCand_id2(1),1);
    SujestedLoc2=[pathFind_nd2(NewLocID,1),pathFind_nd2(NewLocID,2)];clear NewLocID
    plot(SujestedLoc2(1,1),SujestedLoc2(1,2),'ks');hold on
    %  (2) Point selection by door crossing Cheking
    %  (3) Final Point Calculation For Refining of path
    locSelect2=PointSelection(Pdr_new(1:2,stp_id+1)',Pdr_new(1:2,stp_id)',...
        SujestedLoc2,RGB_paint);
    % hold on;plot(locSelect2(1,1),locSelect2(1,2),'kh')
    %  (4) path correction
    [LOCnew2,Lthetanew2]=CorectedPathMM(locSelect2,stp_id,Pdr_new,befor_coef);
    hold on;plot(LOCnew2(1,:),LOCnew2(2,:),'r.');drawnow;
    OLD=Pdr_new;clear Pdr_new
    Pdr_new=LOCnew2;
    SL_teta=Lthetanew2;
    % new Particles Location calculation -------------------------------------
    Particle=Gaussian_propag(locSelect2,0.4,np);%Gaussian point generation
    Particle=Inithial_corrected_particle(Particle,locSelect2,RGB_paint,Wall_m);
    % hold on;plot(Particle(:,1),Particle(:,2),'.')
end % Error in est. PF

end
% hold on;plot(LV(:,1),LV(:,2),'m.-');
