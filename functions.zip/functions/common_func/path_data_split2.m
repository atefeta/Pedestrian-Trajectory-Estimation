function [Acc,Gyr,Mag,AHR,WIFI,BLE,Lgh,sf_Point,stime,ftime]=path_data_split2(start,...
    finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh)
stime=Posi(start,1);
ftime=Posi(finish,1);
sf_Point(1,1)=stime;
sf_Point(1,2:3)=Posi(start,3:4);
sf_Point(2,1)=ftime;
sf_Point(2,2:3)=Posi(finish,3:4);
% (1) Acce
sa=find(Acce(:,1)>stime & Acce(:,1)<ftime);s_a=sa(1);end_a=sa(end);
Acc(:,4)=Acce(s_a:end_a,1);
Acc(:,1:3)=Acce(s_a:end_a,3:5);                            % [ ax ay az time]
% (2) Gyro
if size(Gyro,1)>=1
  sg=find(Gyro(:,1)>stime & Gyro(:,1)<ftime);s_g=sg(1);end_g=sg(end);
  Gyr(:,4)=Gyro(s_g:end_g,1);
  Gyr(:,1:3)=Gyro(s_g:end_g,3:5);                            % [ gx gy gz time]
else
    Gyr=[];
end

% (3) Magn
sm=find(Magn(:,1)>stime & Magn(:,1)<ftime);s_m=sm(1);end_m=sm(end);
Mag(:,4)=Magn(s_m:end_m,1);
Mag(:,1:3)=Magn(s_m:end_m,3:5);

% (4) Ahrs

if size(Ahrs,1)>=1
    sah=find(Ahrs(:,1)>stime & Ahrs(:,1)<ftime);s_ah=sah(1);end_ah=sah(end);
    AHR(:,1:6)=Ahrs(s_ah:end_ah,3:8);  % AHR(:,1)>> pitch    AHR(:,2)>> Roll   AHR(:,3)>> Yaw
    AHR(:,7)=Ahrs(s_ah:end_ah,1);
else
   
    AHR=[];
end

% (5) WIFI
sw=find(Wifi(:,1)>stime & Wifi(:,1)<ftime);
if size(sw,1)>=1
    s_w=sw(1);end_w=sw(end);
    WIFI(:,1)=Wifi(s_w:end_w,4);       % db
    WIFI(:,2)=Wifi(s_w:end_w,3);       % ID
    WIFI(:,3)=Wifi(s_w:end_w,1);       % time app
else
     WIFI=[];
end
% (6) BLE
sb=find(Ble4(:,1)>stime & Ble4(:,1)<ftime);
if size(sb,1)>=1
    s_b=sb(1);end_b=sb(end);
    BLE(:,1)=Ble4(s_b:end_b,3);        % db
    BLE(:,2)=Ble4(s_b:end_b,2);        % ID
    BLE(:,3)=Ble4(s_b:end_b,1);        % time
else
    BLE=[];
end
% (7) Light
sL=find(Ligh(:,1)>stime & Ligh(:,1)<ftime);s_L=sL(1);end_L=sL(end);
Lgh(:,1)=Ligh(s_L:end_L,3);
Lgh(:,2)=Ligh(s_L:end_L,1);        % t
end