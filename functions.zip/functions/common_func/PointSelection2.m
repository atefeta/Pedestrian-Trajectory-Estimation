function locSelect=PointSelection2(curLoc,preLoc,DtwLoc,rgb,Wall_m,Pdr_new0,stp_i)
% curLoc=Pdr_new2(1:2,stp_id+1)';preLoc=Pdr_new2(1:2,stp_id)';
%DtwLoc=SujestedLoc2;rgb=RGB_paint;Pdr_new0=Pdr_new2;stp_i=stp_id
scale=0.05207600;                     % meter/pixel
lonX= -3.48367648;     % lon degree
latY= 40.31320308;     % lat
angle=-8.77680000;
[P0x P0y]=ll2utm([40.31320308 -3.48367648]);
Map_gray=rgb2gray(rgb);mapgray_doubl=im2double(Map_gray);clear Map_gray
sl=0;
dx=DtwLoc(1,1)-curLoc(1,1);
dy=DtwLoc(1,2)-curLoc(1,2);
teta=atan2(dx,dy);
d2dtw=sqrt((dx).^2 + (dy).^2);
for j=1:10% each sample on line between curLoc and dtwLoc
    % j=j+1
    sl=sl+0.1*d2dtw;
    sx=curLoc(1,1)+sl*sin(teta);
    sy=curLoc(1,2)+sl*cos(teta);% hold on;plot(sx ,sy,'rh')
    % new prev loc based new sample on line
    [sx_pxl sy_pxl]=Meter2pixel([sx,sy],rgb,angle,scale,P0x,P0y);
    % sample wall on and wall distance cheking
    Dis=sqrt(sum( (( repmat ([sx sy],size(Wall_m,1) ,1))-Wall_m).^2 ,2));
    mindis2wall=min(Dis);mapgray_doubl(sy_pxl,sx_pxl);
     if mapgray_doubl(sy_pxl,sx_pxl)<=.6 || mindis2wall<=0.25
         clear Dis mindis2wall
         continue
     end
    LocpreNew=newPrevLoc(sx,sy,curLoc,preLoc,Pdr_new0,stp_i);
    % hold on;plot(LocpreNew(1,1),LocpreNew(1,2) ,'kh')
    clear preLoc
    preLoc=LocpreNew;clear LocpreNew
    sdx=sx-preLoc(1,1);
    sdy=sy-preLoc(1,2);
    steta=atan2(sdx,sdy);
    d2prev=sqrt((sdx).^2 + (sdy).^2);
    counter=0;SL=0;
    for i=1:10%i=i+1 
        SL= SL + 0.1*d2prev;
        sxn=preLoc(1,1)+SL*sin(steta);
        syn=preLoc(1,2)+SL*cos(steta);
        [sxn_pxl syn_pxl]=Meter2pixel([sxn,syn],rgb,angle,scale,P0x,P0y);
        pixXYclr=[sxn_pxl syn_pxl mapgray_doubl(syn_pxl,sxn_pxl)];
        %hold on;plot(sxn ,syn,'ko')
        %drawnow
        if mapgray_doubl(syn_pxl,sxn_pxl)<=.6 % black figure(2);imshow(mapgray_doubl)
            counter=counter+1% detection of wall crossing
        end
    end % pre2sample
    if counter==0
        locSelect=[sx sy];%hold on;plot(sx ,sy,'ro')
        break
    end
end % j cur2dtw

end % function