function pdr_old=PDR_system(X,Y,start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh)
% x_ref,y_ref,...
% Acce=Data.Acce;Posi=Data.Posi;Gyro=Data.Gyro;Magn=Data.Magn;Ahrs=Data.Ahrs;Wifi=Data.Wifi;
% Ble4=Data.Ble4;Ligh=Data.Ligh;
[Acc1,Gyr1,Mag1,AHR1,WIFI1,BLE1,Lgh1,sf_Point,stim,ftim]= path_data_split2(start,finish,Acce,Posi,Gyro,Magn,Ahrs,Wifi,Ble4,Ligh);
Acc=Acc1;Gyr=Gyr1;Mag=Mag1;AHR=AHR1;
%% Heading from Madgwick
beta=0.08;
gyroMeasError=pi*(50 / 180);
beta=sqrt(3 / 4) * gyroMeasError
zeta=0.016;
[BearinG_Madg,tim,phone_state]=Heading_Madgwick(Acc,Mag,Gyr,beta,zeta);
%% step detection in each path
[StanceBegins_idx,time_step,Num_steps] = Step_Detection(Acc);
% WinT=200;tim0=1;%% interquartile range and Median absolute Deviation 
% [StanceBegins_idx,time_step,Num_steps,Acc_mag_filt2,binaryFilt2,Iqrr] = Step_DetectionMagnew(Acc,WinT,tim0);
Step_events=StanceBegins_idx;Timestep=time_step;
Step_event=Step_events;% number of samples that step is evented                        
Number_steps=length(Step_event);  
%% StepLenght estimation
K=0.33;
num_samples_Acc=size(Acc,1);
% 1) ACCe Magnitude
M_Acc=sqrt(Acc(:,1).^2+Acc(:,2).^2+Acc(:,3).^2);
% 2) Filter
tiempo_experimento=(Acc(end,4)-Acc(1,4));
num_acc_samples=size(Acc,1);                             % Acce samples
freq_Acc=ceil(num_acc_samples/tiempo_experimento);       % acc samples/s o Hz
[b,a] = butter(4,3/freq_Acc,'low');
M_Acc=filtfilt(b,a,M_Acc);
% 3) Formula Analog Devices (Weiberg paper)  SL Estimation
sample_ini=1;
num_Step_events=length(Step_event);
for i=1:num_Step_events                    % for each of the steps detected
    sample_Step_event=Step_event(i);
    Acc_max(i)=max(M_Acc(sample_ini:sample_Step_event));
    Acc_min(i)=min(M_Acc(sample_ini:sample_Step_event));
    Bounce(i)=(Acc_max(i)-Acc_min(i))^(1/4);
    StrideLengths(i)=Bounce(i)*K*2;
    sample_ini= sample_Step_event;
end
%% heading in each step
for sn=1:size(Timestep,1)
    [~,dd]=min(abs(bsxfun(@minus, tim(1,:),...
        repmat( Timestep(sn),[1, size(tim,2)] ))));
    hse(sn)=dd;  
end
%% Destination from Madgwick Heading
SL=StrideLengths;
gg=size(SL,2);
x_y(1,1)=X(start);
x_y(1,2)=Y(start);
for j=1:gg
    teta_brng(j)=BearinG_Madg(1,hse(1,j)); % teta: angle to geo. north axis
    x_y(j+1,1)=x_y(j,1)+(SL(1,j)*sin(deg2rad( teta_brng(j))));
    x_y(j+1,2)=x_y(j,2)+(SL(1,j)*cos(deg2rad(teta_brng(j))));
end
pdr_old.coor=x_y;
pdr_old.time=time_step;
pdr_old.tetha=teta_brng;
pdr_old.Sl=SL;
pdr_old.stime=stim;
end






  













