function cor_p=Inithial_corrected_particle(Par,Mu0,RGB_paint,Wall_mtr)
% Par=Particle;Mu0=mu;Wall_mtr=Wall_m;
%hold on;plot(P0(1,1),P0(1,2),'*')
%% on wall 
% hold on ;plot(Particle(onw_id,1),Particle(onw_id,2),'r.')
on_wall = Wall_on_all(Par,RGB_paint); 
onw_id = find(on_wall==1); % find particles on Wall
%% (1) wall crossing detection and correction -----------------------------
for jj=1:size(Par,1) % wall crossing , on wall and distance wall cheking
    flg_0(jj)=Wall_Crossing(Par(jj,:),Mu0,RGB_paint);
end
id0_wcr=find(flg_0==1);% hold on ;plot(Particle(id0_wcr,1),Particle(id0_wcr,2),'m.')
%hold on ;plot(Particle(:,1),Particle(:,2),'w.')
% wall crossing corection
if size(id0_wcr,2)~=0
    wcr_prt=Par(id0_wcr' ,:);
    summask=on_wall+flg_0;
    vid=find(summask==0);
    valid_loc=Par(vid' ,:);
    %hold on ;plot(Particle(vid,1),Particle(vid,2),'ko')
    loc_cr=Cross_2_Median(wcr_prt,valid_loc);
    Par(id0_wcr' ,:)=loc_cr;%hold on ;plot(Particle(:,1),Particle(:,2),'go')
end
%% (2) on wall correction -------------------------------------------------
on_wall = Wall_on_all(Par,RGB_paint);
onw_id = find(on_wall==1);
if size(onw_id,2)~=0
    onwall_prt=Par(onw_id' ,:);
    nowall_id=find(on_wall==0);
    nowall=Par(nowall_id' ,:);
    loc=OnWall2closestpoint(onwall_prt,nowall);
    Par(onw_id' ,:)=loc;%hold on ;plot(Particle(:,1),Particle(:,2),'b.')
end
%% (3) distance correction ------------------------------------------------
idex_wdis=Dis_Part2Wallpoint(Par,Wall_mtr,0.25);
mask=zeros(size(Par,1),1);
mask(idex_wdis)=1;
mask=mask.*(1:size(Par,1))';
if size(idex_wdis,1)~=0
    walclos_loc=Par(idex_wdis,:);
    valid_id=find(mask==0);
    valid_loc=Par(valid_id,:);
    Pos_cls=Closewall_2_closest(walclos_loc,valid_loc) ;
    Par(idex_wdis' ,:)=Pos_cls;

end 


cor_p=Par;
end