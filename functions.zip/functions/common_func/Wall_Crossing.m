function Wflg=Wall_Crossing(par_new,par_old,rgb)
%par_new=PLoc(jj,:);par_old=Particle(jj,:);rgb=RGB_paint;
% lat lon to pixel
scale=0.05207600;                     % meter/pixel
angle=-8.77680000;
[P0x P0y]=ll2utm([40.31320308 -3.48367648]);
Map_gray=rgb2gray(rgb);% figure(3); imshow(Map_gray)
% pixel_wall=find(Map_gray<=255);Map_gray(pixel_wall)==0;
black=find(Map_gray < 5);Map_gray(black)=0;
l=0;
d_x=par_new(1,1)-par_old(1,1);
d_y=par_new(1,2)-par_old(1,2);
teta=atan2(d_x,d_y);
d=sqrt((d_x).^2 + (d_y).^2);
counter=0;
for j=1:10
    l=l+0.1*d;
    xn=par_old(1,1)+l*sin(teta);
    yn=par_old(1,2)+l*cos(teta);
   [xn_pxl yn_pxl]=Meter2pixel([xn,yn],rgb,angle,scale,P0x,P0y);
   if (xn_pxl> size(Map_gray,2) || yn_pxl>=size(Map_gray,1)... 
       || xn_pxl< 1 ||  yn_pxl<=1)
       counter=0;
       break
   end
   %hold on;plot(xn_pxl,yn_pxl,'ms')
   if Map_gray(yn_pxl,xn_pxl)< 1
       counter=counter+1;% detection of wall crossing
       break
   end
end
if  counter==0
     Wflg=0;
else
     Wflg=1;
end   
end
