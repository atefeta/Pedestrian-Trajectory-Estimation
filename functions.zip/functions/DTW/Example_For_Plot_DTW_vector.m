clc;clear all;close all
%%%%%%%%%% load trajectoriy %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load('pdr_sig')
% pdr_sig=pdr_sig./100000;
% pth_sig=pth_sig./100000;

% pdr_sig0=[71 73 75 80 80 80 78 76 75 73 71 71 71 73 75 76 76 75 76 76 75 73 71 70 70 69 68 68 72 74 78 79 80];
% pth_sig0=[69 69 73 75 79 80 79 78 76 73 72 71 70 70 69 69 69 71 73 75 76 76 76 76 76 75 73 71 70 70 71 73 75 77 80 80]-4;
pdr_sig0=[71 73 75 80 80 80 78 76 75 73 71 71 71 73 75 76 76 75 76 76];
pth_sig0=[69 69 73 75 79 80 79 78 76 73 72 71 70 70 69 69 69 71 73 75 76 76 76]-4;


pdr_sig=[1:size(pdr_sig0,2)]';
pdr_sig(:,2)=pdr_sig0';

pth_sig=[1:size(pth_sig0,2)]';
pth_sig(:,2)=pth_sig0';


plot(pdr_sig(:,1),pdr_sig(:,2),'b.-','LineWidth',1,'MarkerSize',20);hold on
plot(pth_sig(:,1),pth_sig(:,2),'r.-','LineWidth',1,'MarkerSize',20);hold on
%%%% Time warping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% (1) Without Window method  >>>  Eqlid. Similarity
[w01,Dist0,DM0,k0]=DTW_2D(pdr_sig,pth_sig);% w01(:,1) >> pth_sig ,   w01(:,2) >> pdr_sig
%[w01,Dist0,DM0,k0]=DTW_2DCosine(pdr_sig,pth_sig);% w01(:,1) >> pth_sig ,   w01(:,2) >> pdr_sig
% [w1,Dist,DM,k]=DTW_2D(pth_sig,pdr_sig);
% Path1=[w01 w1]; % ////// goood and selected to paper
%% Plot

for i=1:size(w01,1)
    plot( [pth_sig(w01(i,1),1) pdr_sig(w01(i,2),1)],[pth_sig(w01(i,1),2) pdr_sig(w01(i,2),2)],'k' )
    hold on
   
end
legend('R sequence','Q sequence')

figure()
plot(w01(:,2),w01(:,1),'.-','MarkerSize',15)
grid minor
ax = gca;
ax.GridLineStyle = '-';

%% %%
% g_x = 1:1:w01(end,2);
% g_y = 1:1:w01(end,1);
% ax = axes('xlim', [.5 w01(end,2)], 'ylim', [.5 w01(end,1)]);
% % Turn on the minor grid lines
% grid(ax, 'minor')
% % Modify the location of the x and y minor tick marks
% ax.XAxis.MinorTickValues = g_x;
% ax.YAxis.MinorTickValues = g_y;