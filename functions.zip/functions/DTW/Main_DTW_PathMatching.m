clc;clear all;close all
%%%%%%%%%% load trajectoriy %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('pdr_sig')
plot(pdr_sig(:,1),pdr_sig(:,2),'b.');hold on
plot(pth_sig(:,1),pth_sig(:,2),'r.');
%%%% Time warping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% (1) Without Window method  >>>  Eqlid. Similarity
[w01,Dist0,DM0,k0]=DTW_2D(pdr_sig,pth_sig);
[w1,Dist,DM,k]=DTW_2D(pth_sig,pdr_sig);
Path1=[w01 w1]; % ////// goood and selected to paper
%% (2) Without Window method  >>> Cosine Similarity
[w01_c,Dist0_c,DM0_c,k0_c]=DTW_2DCosine(pdr_sig,pth_sig);
[w1_c,Dist_c,DM_c,k_c]=DTW_2DCosine(pth_sig,pdr_sig);
Path2=[w01_c w1_c];  % ////// goood
%% (3) method with window
wnd=13;
wnd2=13;
[pathWrapp, Distt,DisM,k,Ws]=DTW_Wind(pdr_sig,pth_sig,wnd);
[pathWrapp2, Distt2,DisM2,k2,WS]=DTW_Wind(pth_sig,pdr_sig,wnd2);
Path3=[pathWrapp pathWrapp2];  % ////// goood
%% (5) method with window
window_size=13
[d, P,wins] = dtwWndow(pdr_sig,pth_sig,window_size); % ////// goood
[rw,cl]=find(P==1);
Path4=[rw cl];  % ////// goood


