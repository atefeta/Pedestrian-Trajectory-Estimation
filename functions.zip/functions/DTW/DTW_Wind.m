function [Wp1, Distf,DMat,kn,wndo]=DTW_Wind(A_sign,B_sign,wndo)
ns=size(A_sign,1);
nt=size(B_sign,1);
wndo=max(wndo, abs(ns-nt)); % adapt window size
%% initializing of Distance matrix
DM0=zeros(ns+1,nt+1)+Inf; % cache matrix
DM0(1,1)=0;
%% begin dynamic programming
for i=1:ns
    for j=max(i-wndo,1):min(i+wndo,nt)
        oost=norm(A_sign(i,:)-B_sign(j,:));
        DM0(i+1,j+1)=oost + min( [DM0(i,j+1), DM0(i+1,j), DM0(i,j)] );
    end
end
DMat=DM0(2:end,2:end);
M=size(DMat,1);
N=size(DMat,2);
Distf=DMat(M,N);
n=N;
m=M;
kn=1; % k is the normalizing factor
Wp1=[M N]; % w is the optimal path
while ((n+m)~=2)
    if (n-1)==0
        m=m-1;
    elseif (m-1)==0
        n=n-1;
    else 
      [values,number]=min([DMat(m-1,n),DMat(m,n-1),DMat(m-1,n-1)]);
      switch number
      case 1
        m=m-1;
      case 2
        n=n-1;
      case 3
        m=m-1;
        n=n-1;
      end
  end
    kn=kn+1;
    Wp1=[m n; Wp1]; % this replace the above sentence. Thanks Pau Mic�
end
end