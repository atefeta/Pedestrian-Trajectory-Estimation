function [w1i,Disti,DdM,k]=DTW_2DCosine(A_sigg,B_sigg)
% A_sigg=pdr_sig;B_sigg=pth_sig;
% % initializing of Distance matrix
dm = 1./simCosin(B_sigg',A_sigg');
DdM=zeros(size(dm)); % updated version of d  >>> N_routh * N_pdr
DdM(1,1)=dm(1,1);
M=size(B_sigg,1);
N=size(A_sigg,1);
for m=2:M
    DdM(m,1)=dm(m,1)+DdM(m-1,1);
end
for n=2:N
    DdM(1,n)=dm(1,n)+DdM(1,n-1);
end
for m=2:M
    for n=2:N
        DdM(m,n)=dm(m,n)+min(DdM(m-1,n),min(DdM(m-1,n-1),DdM(m,n-1))); 
        % this double MIn construction improves in 10-fold the Speed-up. Thanks Sven Mensing
    end
end
Disti=DdM(M,N);
n=N;
m=M;
k=1; % k is the normalizing factor
w1i=[M N]; % w is the optimal path
while ((n+m)~=2)
    if (n-1)==0
        m=m-1;
    elseif (m-1)==0
        n=n-1;
    else 
      [values,number]=min([DdM(m-1,n),DdM(m,n-1),DdM(m-1,n-1)]);
      switch number
      case 1
        m=m-1;
      case 2
        n=n-1;
      case 3
        m=m-1;
        n=n-1;
      end
  end
    k=k+1;
    w1i=[m n; w1i]; % this replace the above sentence. Thanks Pau Mic�
end

end