clc;clear all;close all
%%%%%%%%%% load trajectoriy %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('pdr_sig')
pdr_sig=pdr_sig./100000;
pth_sig=pth_sig./100000;
plot(pdr_sig(:,1),pdr_sig(:,2),'b.-');hold on
plot(pth_sig(:,1),pth_sig(:,2),'r.-');hold on
%%%% Time warping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% (1) Without Window method  >>>  Eqlid. Similarity
%[w01,Dist0,DM0,k0]=DTW_2D(pdr_sig,pth_sig);% w01(:,1) >> pth_sig ,   w01(:,2) >> pdr_sig
%[w01,Dist0,DM0,k0]=DTW_2DCosine(pdr_sig,pth_sig);% w01(:,1) >> pth_sig ,   w01(:,2) >> pdr_sig
wndo=23;
[w01,Dist0,DM0,k0,wndo]=DTW_Wind(pth_sig,pdr_sig,wndo)
% [w1,Dist,DM,k]=DTW_2D(pth_sig,pdr_sig);
% Path1=[w01 w1]; % ////// goood and selected to paper
%% Plot

for i=1:size(w01,1)
    plot( [pth_sig(w01(i,1),1) pdr_sig(w01(i,2),1)],[pth_sig(w01(i,1),2) pdr_sig(w01(i,2),2)] )
    hold on
    drawnow
end
figure()
plot(w01(:,2),w01(:,1),'.-','MarkerSize',15)
grid minor
ax = gca;
ax.GridLineStyle = '-';